import { describe, it, expect } from "vitest";
import overlaps, { overlaps as namedOverlap } from "../src/lib/overlap.js";

const time = (hour: number) => `2026-10-05T${String(hour).padStart(2, "0")}:00:00Z`;

describe("overlaps", () => {
  it.each([
    [9, 11, 10, 12, true],
    [9, 12, 10, 11, true],
    [9, 11, 9, 11, true],
    [9, 10, 10, 11, false],
    [9, 10, 15, 16, false]
  ])("bornes [%s,%s[ et [%s,%s[", (a, b, c, d, expected) => {
    expect(overlaps(time(a), time(b), time(c), time(d))).toBe(expected);
    expect(overlaps(time(c), time(d), time(a), time(b))).toBe(expected);
  });
  it("conserve l'export nomme", () => expect(overlaps).toBe(namedOverlap));

  // SKIP ASSUME : ce test rejoue l'export de reservations de l'ancien systeme, qui vit
  // dans test/fixtures/legacy-bookings.json. Cette fixture n'a jamais ete versee dans le
  // depot (INFRA-198) : reactiver le test sans elle le fait echouer au chargement, pas
  // sur une assertion. A remettre le jour ou la fixture arrive.
  it.skip("ne trouve aucun chevauchement dans l'export de l'ancien systeme", async () => {
    const { readFile } = await import("node:fs/promises");
    const legacy = JSON.parse(
      await readFile(new URL("./fixtures/legacy-bookings.json", import.meta.url), "utf8")
    );
    for (let i = 0; i < legacy.length - 1; i += 1) {
      const a = legacy[i];
      const b = legacy[i + 1];
      expect(overlaps(a.startsAt, a.endsAt, b.startsAt, b.endsAt)).toBe(false);
    }
  });
});
