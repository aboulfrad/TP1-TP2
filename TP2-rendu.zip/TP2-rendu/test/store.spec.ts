import { beforeEach, describe, it, expect, vi } from "vitest";

beforeEach(() => vi.resetModules());

describe("store de production", () => {
  it("expose le catalogue et retrouve une salle connue", async () => {
    const { rooms, findRoom } = await import("../src/store.js");
    expect(rooms.map((room) => room.id)).toEqual(["amphi", "salle-a", "salle-b", "labo"]);
    expect(findRoom("salle-a")).toEqual({ id: "salle-a", name: "Salle A", capacity: 12, hourlyRate: 25 });
    expect(findRoom("inconnue")).toBeUndefined();
  });
  it("filtre les reservations reelles sans melanger les salles", async () => {
    const { bookingsForRoom } = await import("../src/store.js");
    expect(bookingsForRoom("salle-a").map((booking) => booking.id)).toEqual(["bk-1001"]);
    expect(bookingsForRoom("amphi").map((booking) => booking.id)).toEqual(["bk-1002"]);
    expect(bookingsForRoom("labo")).toEqual([]);
    expect(bookingsForRoom("inconnue")).toEqual([]);
  });
  it("produit des identifiants uniques successifs", async () => {
    const { nextBookingId } = await import("../src/store.js");
    expect([nextBookingId(), nextBookingId()]).toEqual(["bk-1003", "bk-1004"]);
  });
});
