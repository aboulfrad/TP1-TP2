import { once } from "node:events";
import { vi } from "vitest";

/** Ouvre un serveur isole et attend sa fermeture apres le scenario. */
export async function withApi(run: (api: Api) => Promise<void>): Promise<void> {
  vi.resetModules();
  const { createApp } = await import("../src/app.js");
  const store = await import("../src/store.js");
  const server = createApp().listen(0, "127.0.0.1");
  try {
    if (!server.listening) await once(server, "listening");
    const address = server.address();
    if (!address || typeof address === "string") throw new Error("port HTTP absent");
    const call = async (path: string, init?: RequestInit): Promise<ApiResponse> => {
      const response = await fetch(`http://127.0.0.1:${address.port}${path}`, init);
      return { status: response.status, body: await response.json() as ApiBody };
    };
    await run({ store, call, post: (payload) => call("/bookings", {
      method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload)
    }) });
  } finally {
    await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  }
}

interface ApiBody {
  roomId?: string;
  date?: string;
  slots?: import("../src/lib/availability.js").AvailabilitySlot[];
  error?: string;
  conflictsWith?: string;
  cancelled?: string;
  booking?: import("../src/store.js").Booking;
  bookings?: import("../src/store.js").Booking[];
  rooms?: import("../src/store.js").Room[];
  room?: import("../src/store.js").Room;
  ok?: boolean;
}
interface ApiResponse { status: number; body: ApiBody }
interface Api {
  store: typeof import("../src/store.js");
  call: (path: string, init?: RequestInit) => Promise<ApiResponse>;
  post: (payload: unknown) => Promise<ApiResponse>;
}
