import { test } from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdtempSync, mkdirSync, writeFileSync, rmSync, readFileSync, cpSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { ChecksPlugin } from "../../.opencode/plugin/checks.js";

const shell = (mode) => {
  const temp = mkdtempSync(join(tmpdir(), "tp2-checks-"));
  try {
    mkdirSync(join(temp, "bin"));
    writeFileSync(join(temp, "bin/npm"), '#!/bin/sh\necho "échec simulé" >&2\nexit 17\n', { mode: 0o755 });
    return spawnSync("bash", ["scripts/checks.sh", ...mode], { encoding: "utf8", env: { ...process.env, PATH: join(temp, "bin") + ":" + process.env.PATH } });
  } finally { rmSync(temp, { recursive: true, force: true }); }
};

test("checks soft expose le rouge sans bloquer, strict refuse la livraison", () => {
  const soft = shell([]);
  assert.equal(soft.status, 0);
  assert.match(soft.stderr, /CHECKS_FAILED/);
  const strict = shell(["--strict"]);
  assert.equal(strict.status, 1);
  assert.match(strict.stderr, /échec simulé/);
});

test("hook couvre les trois outils, configs, stderr et erreurs de lancement", async () => {
  let calls = 0;
  const $ = () => ({ cwd() { return this; }, quiet() { return this; }, nothrow() { calls++; return Promise.resolve({ stdout: Buffer.from("CHECKS_OK\n"), stderr: Buffer.from("signal stderr\n") }); } });
  const hooks = await ChecksPlugin({ $, directory: process.cwd() });
  for (const input of [{ tool: "edit", args: { filePath: "src/lib/price.ts" } }, { tool: "write", args: { filePath: "eslint.config.js" } }, { tool: "apply_patch", args: { patchText: "*** Update File: src/lib/price.ts" } }]) {
    const output = { output: "outil" };
    await hooks["tool.execute.after"](input, output);
    assert.match(output.output, /CHECKS_OK/); assert.match(output.output, /signal stderr/);
  }
  assert.equal(calls, 3);
  await hooks["tool.execute.after"]({ tool: "read", args: { filePath: "src/lib/price.ts" } }, { output: "" });
  assert.equal(calls, 3);
  const broken = await ChecksPlugin({ $() { throw new Error("commande inaccessible"); }, directory: process.cwd() });
  const output = { output: "" };
  await broken["tool.execute.after"]({ tool: "edit", args: { filePath: "src/app.ts" } }, output);
  assert.match(output.output, /CHECKS_FAILED.*commande inaccessible/);
});

test("les six rôles Codex et les deux checkpoints sont branchés", () => {
  for (const name of ["finder", "explorer", "planner", "dev", "reviewer", "tester"]) {
    assert.match(readFileSync(`.codex/agents/${name}.toml`, "utf8"), new RegExp(`name = "${name}"`));
  }
  const hooks = JSON.parse(readFileSync(".codex/hooks.json", "utf8"));
  assert.ok(hooks.hooks.PostToolUse.length); assert.ok(hooks.hooks.Stop.length);
  assert.match(readFileSync(".githooks/pre-commit", "utf8"), /npm run check/);
  assert.match(readFileSync(".github/workflows/ci.yml", "utf8"), /npm run check/);
});


test("checkpoint Codex strict depuis un sous-dossier, continuation et trace JSON", () => {
  const temp = mkdtempSync(join(tmpdir(), "tp2-hook-check-"));
  try {
    mkdirSync(join(temp, ".codex/hooks"), { recursive: true });
    mkdirSync(join(temp, "scripts"));
    mkdirSync(join(temp, "src"));
    mkdirSync(join(temp, "test"));
    cpSync(".codex/hooks/checks.py", join(temp, ".codex/hooks/checks.py"));
    const script = join(temp, "scripts/checks.sh");
    writeFileSync(script, '#!/bin/sh\necho CHECKS_FAILED >&2\nexit 17\n');
    const invoke = (event) => {
      const result = spawnSync("/usr/bin/python3", [join(temp, ".codex/hooks/checks.py")], { input: JSON.stringify({ cwd: join(temp, "src"), ...event }), encoding: "utf8" });
      assert.equal(result.status, 0, result.stderr);
      return JSON.parse(result.stdout);
    };
    const first = invoke({ hook_event_name: "Stop", session_id: "test-local" });
    assert.equal(first.decision, "block");
    assert.match(first.reason, /CHECKS_FAILED/);
    const repeated = invoke({ hook_event_name: "Stop", stop_hook_active: true });
    assert.equal(repeated.continue, false);
    writeFileSync(script, '#!/bin/sh\necho CHECKS_OK\nexit 0\n');
    assert.match(invoke({ hook_event_name: "Stop" }).systemMessage, /CHECKS_OK/);
    const records = readFileSync(join(temp, ".opencode/scratch/codex-hook-events.jsonl"), "utf8").trim().split("\n").map(JSON.parse);
    assert.deepEqual(records.map(x => x.exit_code), [17, 17, 0]);
    assert.ok(records.every(x => x.strict));
  } finally { rmSync(temp, { recursive: true, force: true }); }
});


test("prepare ne configure jamais le dépôt parent d’une archive imbriquée", () => {
  const temp = mkdtempSync(join(tmpdir(), "tp2-parent-hook-"));
  try {
    const init = spawnSync("git", ["init", "-q", temp], { encoding: "utf8" });
    assert.equal(init.status, 0, init.stderr);
    const nested = join(temp, "archive"); mkdirSync(nested);
    const setup = spawnSync(process.execPath, [resolve("scripts/install-hooks.mjs")], { cwd: nested, encoding: "utf8" });
    assert.equal(setup.status, 0, setup.stderr);
    assert.match(setup.stdout, /hook du parent conservé/);
    const query = spawnSync("git", ["-C", temp, "config", "--local", "--get", "core.hooksPath"], { encoding: "utf8" });
    assert.equal(query.status, 1);
  } finally { rmSync(temp, { recursive: true, force: true }); }
});
