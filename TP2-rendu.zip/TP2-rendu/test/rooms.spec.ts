import { describe, it, expect } from "vitest";
import { withApi } from "./http.js";

describe("routes catalogue et recherche", () => {
  it("sert la sante et le catalogue reel", async () => {
    await withApi(async ({ call, store }) => {
      expect(await call("/health")).toEqual({ status: 200, body: { ok: true } });
      expect(await call("/rooms")).toEqual({ status: 200, body: { rooms: store.rooms } });
    });
  });
  it("consulte une salle occupee et ses seules reservations", async () => {
    await withApi(async ({ call, store }) => {
      expect(await call("/rooms/salle-a")).toEqual({ status: 200, body: {
        room: store.findRoom("salle-a"), bookings: store.bookingsForRoom("salle-a")
      } });
    });
  });
  it("consulte une salle libre", async () => {
    await withApi(async ({ call, store }) => {
      expect(await call("/rooms/labo")).toEqual({ status: 200, body: { room: store.findRoom("labo"), bookings: [] } });
    });
  });
  it("refuse une salle absente", async () => {
    await withApi(async ({ call }) => expect(await call("/rooms/cave")).toEqual({ status: 404, body: { error: "salle inconnue" } }));
  });
  it("liste et filtre les reservations sans melanger les salles", async () => {
    await withApi(async ({ call, store }) => {
      expect((await call("/bookings")).body.bookings).toEqual(store.bookings);
      expect((await call("/bookings?roomId=amphi")).body.bookings).toEqual(store.bookingsForRoom("amphi"));
      expect((await call("/bookings?roomId=cave")).body.bookings).toEqual([]);
    });
  });
});
