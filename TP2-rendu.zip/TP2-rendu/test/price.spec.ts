import { describe, it, expect } from "vitest";
import priceFor, { priceFor as namedPrice, hoursBetween, isWeekend } from "../src/lib/price.js";

const salleA = { id: "salle-a", name: "Salle A", capacity: 12, hourlyRate: 25 };
const labo = { ...salleA, hourlyRate: 40 };

describe("priceFor", () => {
  it.each([
    ["2026-10-05T09:00:00Z", "2026-10-05T11:00:00Z", 50],
    ["2026-10-10T09:00:00Z", "2026-10-10T11:00:00Z", 70],
    ["2026-10-11T09:00:00Z", "2026-10-11T11:00:00Z", 70],
    ["2026-10-05T09:00:00Z", "2026-10-05T10:30:00Z", 37.5],
    ["2026-10-09T23:30:00Z", "2026-10-10T00:30:00Z", 25],
    ["2026-10-11T23:30:00Z", "2026-10-12T00:30:00Z", 45]
  ])("facture selon le debut UTC %s", (start, end, expected) => {
    expect(priceFor(salleA, start, end)).toBe(expected);
  });
  it("retourne 100 numerique pour deux heures a 40 le samedi", () => {
    const price = priceFor(labo, "2026-10-10T09:00:00Z", "2026-10-10T11:00:00Z");
    expect(price).toBe(100);
    expect(typeof price).toBe("number");
    expect(priceFor).toBe(namedPrice);
  });
  it("compte les heures fractionnaires", () => {
    expect(hoursBetween("2026-10-05T09:00:00Z", "2026-10-05T12:30:00Z")).toBe(3.5);
  });
  it("reconnait samedi dimanche et semaine en UTC", () => {
    expect(isWeekend("2026-10-10T09:00:00Z")).toBe(true);
    expect(isWeekend("2026-10-11T09:00:00Z")).toBe(true);
    expect(isWeekend("2026-10-09T23:30:00Z")).toBe(false);
  });
});
