import { describe, expect, it } from "vitest";
import requireObject, { requireObject as namedObject, requireString, requireDate, requireDay, requirePositiveInt, ValidationError } from "../src/lib/validate.js";

describe("validation", () => {
  it.each([null, undefined, [], "texte", 42, true])("refuse les payloads non objets : %j", (value) => {
    expect(() => requireObject(value)).toThrow(ValidationError);
  });
  it("preserve l'objet et l'export nomme", () => {
    const payload = { who: " equipe " };
    expect(requireObject).toBe(namedObject);
    expect(requireObject(payload)).toBe(payload);
    expect(requireString(payload, "who")).toBe(" equipe ");
  });
  it.each([undefined, null, "", "  ", 4, false])("refuse les chaines absentes ou invalides : %j", (who) => {
    expect(() => requireString({ who }, "who")).toThrow(ValidationError);
  });
  it.each([
    "2026-10-05T09:00:00Z", "2026-10-05T09:00:00.123Z", "2024-02-29T00:00:00Z"
  ])("accepte UTC exact : %s", (date) => {
    expect(requireDate({ date }, "date")).toBe(date);
  });
  it.each([
    "2026-10-05", "2026-10-05T09:00:00", "2026-10-05T09:00:00+00:00",
    "2026-10-05T09:00:00.1Z", "2026-10-05T09:00:00.1234Z", "2026-02-29T00:00:00Z",
    "2026-04-31T00:00:00Z", "2026-13-01T00:00:00Z", "2026-10-05T24:00:00Z",
    "2026-10-05T09:60:00Z", "2026-10-05T09:00:60Z", "2026-00-01T00:00:00Z",
    "2026-10-00T00:00:00Z", "texte"
  ])("refuse format ou calendrier invalide : %s", (date) => {
    expect(() => requireDate({ date }, "date")).toThrow(ValidationError);
  });
  it.each([undefined, null, 0, -1, 1.5, "2", NaN, Infinity])("refuse entier invalide : %s", (people) => {
    expect(() => requirePositiveInt({ people }, "people")).toThrow(ValidationError);
  });
  it("accepte un entier positif", () => expect(requirePositiveInt({ people: 12 }, "people")).toBe(12));
  it.each(["2026-10-05", "2024-02-29", "2000-02-29", "0000-02-29", "9999-12-31"])("accepte un jour exact : %s", (day) => {
    expect(requireDay(day)).toBe(day);
  });
  it.each([
    undefined, null, 42, true, [], ["2026-10-05"], { value: "2026-10-05" }, "", " ",
    " 2026-10-05", "2026-10-05 ", "2026-1-05", "26-10-05", "2026-10-05T00:00:00Z",
    "2026-02-29", "1900-02-29", "2026-04-31", "2026-13-01", "2026-00-01", "2026-10-00", "2026-10-32"
  ])("refuse un jour absent ou invalide : %j", (day) => {
    expect(() => requireDay(day)).toThrow(ValidationError);
  });
});
