import { describe, it, expect } from "vitest";
import { withApi } from "./http.js";

const payload = {
  roomId: "labo", who: "equipe", people: 4,
  startsAt: "2026-11-02T09:00:00Z", endsAt: "2026-11-02T10:00:00Z"
};

const invalidPayloads: [string, unknown][] = [
  ["objet absent", null], ["tableau", []], ["primitive", 42],
  ["champ absent", { ...payload, who: undefined }], ["chaine vide", { ...payload, who: " " }],
  ["salle inconnue", { ...payload, roomId: "cave" }],
  ["capacite depassee", { ...payload, people: 21 }], ["zero personnes", { ...payload, people: 0 }],
  ["fraction personnes", { ...payload, people: 1.5 }], ["chaine personnes", { ...payload, people: "4" }],
  ["date calendaire impossible", { ...payload, startsAt: "2026-02-29T09:00:00Z" }],
  ["date non UTC", { ...payload, startsAt: "2026-11-02T09:00:00+00:00" }],
  ["fin avant debut", { ...payload, endsAt: "2026-11-02T08:00:00Z" }],
  ["fin egale debut", { ...payload, endsAt: payload.startsAt }]
];

describe("API reservations", () => {
  it.each(invalidPayloads)("refuse %s sans ecriture ni consommation d'identifiant", async (_label, invalid) => {
    await withApi(async ({ post, call, store }) => {
      const before = structuredClone(store.bookings);
      const response = await post(invalid);
      expect(response.status).toBe(400);
      expect(response.body.error).toEqual(expect.any(String));
      expect(store.bookings).toEqual(before);
      expect((await call("/bookings")).body.bookings).toEqual(before);
      const valid = await post(payload);
      expect(valid.status).toBe(201);
      expect(valid.body.booking?.id).toBe("bk-1003");
      expect((await call("/bookings?roomId=labo")).body.bookings).toEqual([valid.body.booking]);
    });
  });
  it("rend une erreur JSON 400 pour une syntaxe JSON invalide", async () => {
    await withApi(async ({ call, post, store }) => {
      const before = structuredClone(store.bookings);
      const response = await call("/bookings", {
        method: "POST", headers: { "content-type": "application/json" }, body: '{"roomId":'
      });
      expect(response).toEqual({ status: 400, body: { error: "JSON invalide" } });
      expect((await call("/bookings")).body.bookings).toEqual(before);
      expect((await post(payload)).body.booking?.id).toBe("bk-1003");
    });
  });
  it("cree puis consulte un prix week-end numerique a capacite exacte", async () => {
    await withApi(async ({ post, call }) => {
      const response = await post({ ...payload, people: 20,
        startsAt: "2026-10-10T09:00:00Z", endsAt: "2026-10-10T11:00:00Z" });
      expect(response.status).toBe(201);
      expect(response.body.booking).toMatchObject({ price: 100, id: "bk-1003", people: 20 });
      expect(typeof response.body.booking?.price).toBe("number");
      expect((await call("/bookings?roomId=labo")).body.bookings).toEqual([response.body.booking]);
    });
  });
  it("accepte contigus puis refuse le recouvrement sans consommer d'identifiant", async () => {
    await withApi(async ({ post, call, store }) => {
      const first = await post(payload);
      const second = await post({ ...payload, startsAt: payload.endsAt, endsAt: "2026-11-02T11:00:00Z" });
      expect(first.status).toBe(201);
      expect(second.status).toBe(201);
      const before = structuredClone(store.bookings);
      const clash = await post({ ...payload, startsAt: "2026-11-02T09:30:00Z" });
      expect(clash).toEqual({ status: 409, body: { error: "creneau deja reserve", conflictsWith: first.body.booking?.id } });
      expect((await call("/bookings")).body.bookings).toEqual(before);
      const third = await post({ ...payload, startsAt: "2026-11-02T11:00:00Z", endsAt: "2026-11-02T12:00:00Z" });
      expect(third.status).toBe(201);
      expect(third.body.booking?.id).toBe("bk-1005");
      expect((await call("/bookings?roomId=labo")).body.bookings).toEqual([first.body.booking, second.body.booking, third.body.booking]);
    });
  });
  it("annule une reservation et permet de reutiliser son creneau", async () => {
    await withApi(async ({ post, call }) => {
      const created = await post(payload);
      expect(created.status).toBe(201);
      const response = await call(`/bookings/${created.body.booking?.id}`, { method: "DELETE" });
      expect(response).toEqual({ status: 200, body: { cancelled: "bk-1003" } });
      expect((await call("/bookings?roomId=labo")).body.bookings).toEqual([]);
      const replacement = await post(payload);
      expect(replacement.status).toBe(201);
      expect(replacement.body.booking?.id).toBe("bk-1004");
      expect((await call("/bookings?roomId=labo")).body.bookings).toEqual([replacement.body.booking]);
    });
  });
  it("refuse la suppression absente sans mutation", async () => {
    await withApi(async ({ call, store }) => {
      const before = structuredClone(store.bookings);
      expect(await call("/bookings/absente", { method: "DELETE" })).toEqual({ status: 404, body: { error: "reservation inconnue" } });
      expect((await call("/bookings")).body.bookings).toEqual(before);
    });
  });
  it("demarre avec le store initial apres les scenarios de mutation", async () => {
    await withApi(async ({ call, post }) => {
      expect((await call("/bookings")).body.bookings?.map((booking) => booking.id)).toEqual(["bk-1001", "bk-1002"]);
      expect((await call("/bookings?roomId=labo")).body.bookings).toEqual([]);
      expect((await post(payload)).body.booking?.id).toBe("bk-1003");
    });
  });
});
