import { describe, expect, it } from "vitest";
import availableSlots, { availableSlots as namedSlots, type AvailabilitySlot } from "../src/lib/availability.js";
import { withApi } from "./http.js";

const date = "2026-11-02";
const midnight = `${date}T00:00:00.000Z`;
const nextMidnight = "2026-11-03T00:00:00.000Z";
const at = (time: string) => `${date}T${time}Z`;
const slot = (startsAt: string, endsAt: string): AvailabilitySlot => ({ startsAt, endsAt });
const fullDay = [slot(midnight, nextMidnight)];
const dayStart = Date.parse(midnight);
const dayEnd = Date.parse(nextMidnight);
const occupation = (start: string, end: string) => slot(at(start), at(end));
const free = (start: string, end: string) => slot(at(start), at(end));

describe("calcul des disponibilites", () => {
  const scenarios: [string, AvailabilitySlot[], AvailabilitySlot[]][] = [
    ["aucune occupation", [], fullDay],
    ["journee entiere", fullDay, []],
    ["occupation englobante", [slot("2026-11-01T23:00:00Z", "2026-11-04T01:00:00Z")], []],
    ["occupations triees", [occupation("09:00:00", "10:00:00"), occupation("12:00:00", "13:00:00")],
      [free("00:00:00.000", "09:00:00.000"), free("10:00:00.000", "12:00:00.000"), slot(at("13:00:00.000"), nextMidnight)]],
    ["ordre inverse", [occupation("12:00:00", "13:00:00"), occupation("09:00:00", "10:00:00")],
      [free("00:00:00.000", "09:00:00.000"), free("10:00:00.000", "12:00:00.000"), slot(at("13:00:00.000"), nextMidnight)]],
    ["chevauchements inclusions et adjacences", [
      occupation("11:00:00", "13:00:00"), occupation("09:00:00", "12:00:00"),
      occupation("09:00:00", "10:00:00"), occupation("10:00:00", "11:00:00"), occupation("13:00:00", "14:00:00")
    ], [free("00:00:00.000", "09:00:00.000"), slot(at("14:00:00.000"), nextMidnight)]],
    ["hors journee et bornes exactes", [
      slot("2026-11-01T01:00:00Z", "2026-11-01T02:00:00Z"), slot("2026-11-01T23:00:00Z", midnight),
      slot(nextMidnight, "2026-11-03T01:00:00Z"), slot("2026-11-04T01:00:00Z", "2026-11-04T02:00:00Z")
    ], fullDay],
    ["occupations traversant les minuits", [
      slot("2026-11-01T23:00:00Z", at("02:00:00")), slot(at("22:00:00"), "2026-11-03T01:00:00Z")
    ], [free("02:00:00.000", "22:00:00.000")]],
    ["millisecondes", [occupation("09:00:00.123", "09:00:00.456")],
      [free("00:00:00.000", "09:00:00.123"), slot(at("09:00:00.456"), nextMidnight)]]
  ];
  it.each(scenarios)("calcule le complement : %s", (_name, bookings, expected) => {
    expect(availableSlots(dayStart, dayEnd, bookings)).toEqual(expected);
  });
  it("preserve les objets et leur ordre et expose le meme export", () => {
    const bookings = Object.freeze([
      Object.freeze(occupation("12:00:00", "13:00:00")), Object.freeze(occupation("09:00:00", "10:00:00"))
    ]);
    const before = structuredClone(bookings);
    expect(availableSlots).toBe(namedSlots);
    expect(availableSlots(dayStart, dayEnd, bookings)).toHaveLength(3);
    expect(bookings).toEqual(before);
  });
});

describe("GET /rooms/:id/availability", () => {
  it("renvoie le contrat exact pour une salle libre et la fixture sans occupation d'une autre salle", async () => {
    await withApi(async ({ call, post }) => {
      expect(await call(`/rooms/labo/availability?date=${date}`)).toEqual({
        status: 200, body: { roomId: "labo", date, slots: fullDay }
      });
      expect((await post({ roomId: "salle-b", who: "equipe", people: 2,
        startsAt: "2026-10-05T00:00:00Z", endsAt: "2026-10-06T00:00:00Z" })).status).toBe(201);
      expect(await call("/rooms/salle-a/availability?date=2026-10-05")).toEqual({
        status: 200, body: { roomId: "salle-a", date: "2026-10-05", slots: [
          slot("2026-10-05T00:00:00.000Z", "2026-10-05T09:00:00.000Z"),
          slot("2026-10-05T11:00:00.000Z", "2026-10-06T00:00:00.000Z")
        ] }
      });
    });
  });
  it.each(["", "?date=2026-10-05", "?date=impossible"])("priorise la salle inconnue : %s", async (query) => {
    await withApi(async ({ call }) => {
      expect(await call(`/rooms/inconnue/availability${query}`)).toEqual({ status: 404, body: { error: "salle inconnue" } });
    });
  });
  it.each([
    "", "?date=", "?date=2026-10-05&date=2026-10-05", "?date[]=2026-10-05",
    "?date[value]=2026-10-05", "?date=%202026-10-05", "?date=2026-10-05%20",
    "?date=2026-2-03", "?date=2026-02-29", "?date=2026-04-31", "?date=2026-13-01",
    "?date=2026-10-05T00:00:00Z"
  ])("refuse un parametre invalide : %s", async (query) => {
    await withApi(async ({ call, post, store }) => {
      const before = structuredClone(store.bookings);
      const response = await call(`/rooms/labo/availability${query}`);
      expect(response.status).toBe(400);
      expect(response.body).toEqual({ error: expect.any(String) });
      expect(store.bookings).toEqual(before);
      const created = await post({ roomId: "labo", who: "equipe", people: 2,
        startsAt: at("09:00:00"), endsAt: at("10:00:00") });
      expect(created.status).toBe(201);
      expect(created.body.booking?.id).toBe("bk-1003");
    });
  });
  it.each([
    ["2024-02-29", "2024-03-01T00:00:00.000Z"],
    ["2026-12-31", "2027-01-01T00:00:00.000Z"],
    ["0000-02-29", "0000-03-01T00:00:00.000Z"],
    ["9999-12-31", "+010000-01-01T00:00:00.000Z"]
  ])("calcule les bornes du jour %s", async (day, end) => {
    await withApi(async ({ call }) => {
      expect(await call(`/rooms/labo/availability?date=${day}`)).toEqual({
        status: 200, body: { roomId: "labo", date: day, slots: [slot(`${day}T00:00:00.000Z`, end)] }
      });
    });
  });
  it("calcule des occupations non triees, traversant les minuits, aux bornes exactes et avec millisecondes", async () => {
    await withApi(async ({ call, post, store }) => {
      for (const interval of [
        slot(at("22:00:00"), "2026-11-03T01:00:00Z"),
        slot("2026-11-01T23:00:00Z", at("02:00:00")),
        occupation("12:00:00.123", "13:00:00.456"),
        slot("2026-11-01T22:00:00Z", "2026-11-01T23:00:00Z"),
        slot("2026-11-03T01:00:00Z", "2026-11-03T02:00:00Z")
      ]) {
        expect((await post({ roomId: "labo", who: "equipe", people: 2, ...interval })).status).toBe(201);
      }
      const before = structuredClone(store.bookings);
      expect(await call(`/rooms/labo/availability?date=${date}`)).toEqual({
        status: 200, body: { roomId: "labo", date, slots: [
          free("02:00:00.000", "12:00:00.123"), free("13:00:00.456", "22:00:00.000")
        ] }
      });
      expect(store.bookings).toEqual(before);
    });
  });
  it("ignore les occupations touchant seulement les bornes et renvoie vide pour une journee reservee", async () => {
    await withApi(async ({ call, post }) => {
      for (const interval of [slot("2026-11-01T23:00:00Z", midnight), slot(nextMidnight, "2026-11-03T01:00:00Z")]) {
        expect((await post({ roomId: "labo", who: "equipe", people: 2, ...interval })).status).toBe(201);
      }
      expect((await call(`/rooms/labo/availability?date=${date}`)).body.slots).toEqual(fullDay);
      expect((await post({ roomId: "labo", who: "equipe", people: 2, ...fullDay[0] })).status).toBe(201);
      expect(await call(`/rooms/labo/availability?date=${date}`)).toEqual({
        status: 200, body: { roomId: "labo", date, slots: [] }
      });
    });
  });
  it("reagit a la creation et a l'annulation sans muter les reservations ni consommer d'identifiants", async () => {
    await withApi(async ({ call, post, store }) => {
      const path = `/rooms/labo/availability?date=${date}`;
      const before = structuredClone(store.bookings);
      expect((await call(path)).body.slots).toEqual(fullDay);
      expect(store.bookings).toEqual(before);
      const payload = { roomId: "labo", who: "equipe", people: 2, ...occupation("09:00:00", "10:00:00") };
      const created = await post(payload);
      expect(created.status).toBe(201);
      expect(created.body.booking?.id).toBe("bk-1003");
      const after = structuredClone(store.bookings);
      expect((await call(path)).body.slots).toEqual([
        free("00:00:00.000", "09:00:00.000"), slot(at("10:00:00.000"), nextMidnight)
      ]);
      expect(store.bookings).toEqual(after);
      expect(await call("/bookings/bk-1003", { method: "DELETE" })).toEqual({ status: 200, body: { cancelled: "bk-1003" } });
      expect((await call(path)).body.slots).toEqual(fullDay);
      expect(store.bookings).toEqual(before);
      const replacement = await post(payload);
      expect(replacement.status).toBe(201);
      expect(replacement.body.booking?.id).toBe("bk-1004");
    });
  });
});
