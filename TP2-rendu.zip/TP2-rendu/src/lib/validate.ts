export class ValidationError extends Error {
  status = 400;
}

export function requireObject(payload: unknown): Record<string, unknown> {
  if (typeof payload !== "object" || payload === null || Array.isArray(payload)) {
    throw new ValidationError("objet JSON attendu");
  }
  return payload as Record<string, unknown>;
}

export function requireString(payload: Record<string, unknown>, field: string): string {
  const value = payload[field];
  if (typeof value !== "string" || value.trim() === "") {
    throw new ValidationError(`champ manquant ou vide : ${field}`);
  }
  return value;
}

export function requireDate(payload: Record<string, unknown>, field: string): string {
  const value = requireString(payload, field);
  // UTC canonique, secondes obligatoires, millisecondes optionnelles sur trois chiffres.
  const utc = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{3})?Z$/;
  const timestamp = Date.parse(value);
  const canonical = value.includes(".") ? value : value.replace("Z", ".000Z");
  if (!utc.test(value) || !Number.isFinite(timestamp) || new Date(timestamp).toISOString() !== canonical) {
    throw new ValidationError(`date invalide : ${field}`);
  }
  return value;
}

export function requirePositiveInt(payload: Record<string, unknown>, field: string): number {
  const value = payload[field];
  if (typeof value !== "number" || !Number.isInteger(value) || value <= 0) {
    throw new ValidationError(`entier positif attendu : ${field}`);
  }
  return value;
}

export function requireDay(value: unknown): string {
  if (typeof value !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    throw new ValidationError("date invalide : date (YYYY-MM-DD attendu)");
  }
  const midnight = `${value}T00:00:00.000Z`;
  const timestamp = Date.parse(midnight);
  if (!Number.isFinite(timestamp) || new Date(timestamp).toISOString() !== midnight) {
    throw new ValidationError("date invalide : date");
  }
  return value;
}

export default requireObject;
