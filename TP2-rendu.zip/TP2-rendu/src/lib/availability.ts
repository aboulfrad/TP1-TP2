export interface AvailabilitySlot {
  startsAt: string;
  endsAt: string;
}

export function availableSlots(dayStart: number, dayEnd: number, occupations: readonly AvailabilitySlot[]): AvailabilitySlot[] {
  const occupied = occupations.map(({ startsAt, endsAt }) => ({
    start: Math.max(dayStart, Date.parse(startsAt)),
    end: Math.min(dayEnd, Date.parse(endsAt))
  })).filter(({ start, end }) => start < end)
    .sort((a, b) => a.start - b.start || a.end - b.end);
  const slots: AvailabilitySlot[] = [];
  let cursor = dayStart;
  for (const { start, end } of occupied) {
    if (start > cursor) {
      slots.push({ startsAt: new Date(cursor).toISOString(), endsAt: new Date(start).toISOString() });
    }
    cursor = Math.max(cursor, end);
  }
  if (cursor < dayEnd) {
    slots.push({ startsAt: new Date(cursor).toISOString(), endsAt: new Date(dayEnd).toISOString() });
  }
  return slots;
}

export default availableSlots;
