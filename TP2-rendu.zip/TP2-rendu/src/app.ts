import express, { type ErrorRequestHandler } from "express";
import { roomsRouter } from "./routes/rooms.js";
import { bookingsRouter } from "./routes/bookings.js";

/** Cree le service HTTP de reservation et ses routes. */
export function createApp() {
  const app = express();
  app.use(express.json());
  const jsonErrors: ErrorRequestHandler = (err: unknown, _req, res, next) => {
    if (err instanceof SyntaxError && "type" in err && err.type === "entity.parse.failed") {
      res.status(400).json({ error: "JSON invalide" });
      return;
    }
    next(err);
  };
  app.use(jsonErrors);
  app.get("/health", (_req, res) => res.json({ ok: true }));
  app.use("/rooms", roomsRouter);
  app.use("/bookings", bookingsRouter);
  return app;
}
