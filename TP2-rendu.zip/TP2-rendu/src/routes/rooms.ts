import { Router } from "express";
import { rooms, findRoom, bookingsForRoom } from "../store.js";
import { availableSlots } from "../lib/availability.js";
import { requireDay, ValidationError } from "../lib/validate.js";

export const roomsRouter = Router();

roomsRouter.get("/", (_req, res) => {
  res.json({ rooms });
});

roomsRouter.get("/:id/availability", (req, res) => {
  const room = findRoom(req.params.id);
  if (!room) {
    res.status(404).json({ error: "salle inconnue" });
    return;
  }
  try {
    const date = requireDay(req.query.date);
    const dayStart = Date.parse(`${date}T00:00:00.000Z`);
    const dayEnd = dayStart + 24 * 60 * 60 * 1000;
    const slots = availableSlots(dayStart, dayEnd, bookingsForRoom(room.id));
    res.json({ roomId: room.id, date, slots });
  } catch (err) {
    if (err instanceof ValidationError) {
      res.status(err.status).json({ error: err.message });
      return;
    }
    throw err;
  }
});

roomsRouter.get("/:id", (req, res) => {
  const room = findRoom(req.params.id);
  if (!room) {
    res.status(404).json({ error: "salle inconnue" });
    return;
  }
  res.json({ room, bookings: bookingsForRoom(room.id) });
});
