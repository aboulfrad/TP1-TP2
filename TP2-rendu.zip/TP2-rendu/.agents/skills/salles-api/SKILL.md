---
name: salles-api
description: Explorer, modifier et vérifier cette API de réservation Express/TypeScript avec sa chaîne de spécialistes.
---

1. Lire AGENTS.md et les overrides du chemin concerné. src/lib dispense de JSDoc et exige un default ; le store reste gelé.
2. Dates publiques UTC en string, intervalles [début, fin[, prix numériques ; aucune règle d’ouverture non exprimée. Pour availability, déclarer explicitement l’hypothèse d’une journée UTC complète.
3. Finder localise, explorer explique, planner planifie, dev implémente, reviewer réfute sans corriger, tester exerce HTTP. Briefs autonomes et plans sur disque, pas de délégation récursive par dev.
4. Tests *.spec.ts : vrais appels aux fonctions de production. Réinitialiser le graphe du store entre scénarios, pas entre deux requêtes du même scénario. Attendre fermeture serveur. Seul skip legacy INFRA-198 admis faute de fixture.
5. Exécuter npm run check avant livraison. Les hooks soft signalent les erreurs sans bloquer l’écriture ; CI et pre-commit utilisent strict. Aucun contrôle non exécuté ne vaut un succès.
6. MCP désactivés par défaut : l’API en mémoire et cette tâche n’en ont pas besoin. Réactiver uniquement une intégration utile, avec auth locale et probe réel ; ne jamais écrire un secret dans Git.
7. Aucune persistance prouvée, aucun push au dépôt pédagogique, aucun changement au store legacy. Signaler limites, hypothèses et contexte de chaque mesure.
