import { defineConfig } from "vitest/config";

// La convention .spec.ts est conservée ; les anciens .test.ts sont renommés.
export default defineConfig({
  test: {
    include: ["test/**/*.spec.ts"],
    environment: "node",
    maxWorkers: 1,
    coverage: {
      provider: "v8",
      include: ["src/**/*.ts"],
      exclude: ["src/server.ts"],
      reporter: ["text", "json-summary", "html"],
      thresholds: { statements: 90, lines: 90, functions: 90, branches: 85 }
    }
  }
});
