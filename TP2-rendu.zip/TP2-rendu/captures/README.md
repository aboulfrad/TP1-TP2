# Captures réelles

- `01-demarrage-availability-absente.jpg` : capture du navigateur avant ajout de l’endpoint, complémentaire aux deux sessions.
- `02-session-avant.png` : vraie capture macOS de la session initiale fournie par l’étudiant. Le résultat montre 47 tests réussis et 4 désactivés.
- `03-session-apres.png` : vraie capture macOS de la session finale fournie par l’étudiant. Le résultat montre 141 tests réussis, un test historique désactivé et la validation HTTP indépendante (54 requêtes, 138 assertions).

Les deux captures montrent les résultats. La consigne exacte n’est pas visible dans ces images ; elle est conservée dans les traces des sessions. Aucune image reconstruite n’a été créée. Les sorties JSON/textes dans `preuves/` sont des pièces complémentaires.

Sessions réelles : avant `01a11bb1-72e5-7e10-854c-9c57d2fb6086`, après `01a11bd3-49be-71d3-aa06-bf4c89623314`.
