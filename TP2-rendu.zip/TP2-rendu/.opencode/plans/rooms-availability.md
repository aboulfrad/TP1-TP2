# GET /rooms/:id/availability — plan avant implémentation

## Objectif

Ajouter `GET /rooms/:id/availability?date=YYYY-MM-DD`, qui calcule les intervalles libres d'une salle sur la journée UTC demandée, avec validation, tests unitaires et tests HTTP du code de production.

Contrat d'une réponse `200` :

```json
{
  "roomId": "salle-a",
  "date": "2026-10-05",
  "slots": [
    { "startsAt": "2026-10-05T00:00:00.000Z", "endsAt": "2026-10-05T09:00:00.000Z" },
    { "startsAt": "2026-10-05T11:00:00.000Z", "endsAt": "2026-10-06T00:00:00.000Z" }
  ]
}
```

Les créneaux sont strictement positifs, triés, disjoints et maximaux. Toutes les dates de sortie sont des chaînes UTC produites par `toISOString()`, avec trois chiffres de millisecondes.

## Non-objectifs

- Modifier `src/store.ts`, les identifiants, la facturation ou les routes de réservation existantes.
- Ajouter persistance, dépendance, configuration, horaires d'ouverture, fuseau local, durée minimale de créneau ou règle métier supplémentaire.
- Migrer la validation vers `Result`, modifier les seuils de couverture ou supprimer le skip INFRA-198 sans sa fixture.
- Réparer les modifications préexistantes sans rapport, activer des MCP, committer ou pousser le dépôt pédagogique.

## Hypothèses et décisions

- Une journée est l'intervalle UTC complet `[00:00:00.000Z, minuit du lendemain[`, soit 24 heures. Aucune règle d'ouverture n'est exprimée dans le besoin.
- Les réservations en mémoire occupent des intervalles semi-ouverts `[startsAt, endsAt[`. Elles n'ont aucun statut ; une annulation les retire du store. Les réservations existantes respectent le contrat de création.
- `bookingsForRoom` ne garantit pas le tri. Le calcul trie une copie des occupations et ne modifie aucun tableau ni objet reçu.
- Une salle inconnue renvoie `404 {"error":"salle inconnue"}` avant la validation de `date`, même si celle-ci est absente ou invalide.
- Pour une salle connue, `date` doit être une unique chaîne exacte `YYYY-MM-DD` représentant un jour calendaire valide. Absence, chaîne vide, espaces, timestamp, tableau, objet, duplication du paramètre ou jour impossible renvoient `400 {"error": ...}` via `ValidationError`. Aucun trim ni normalisation permissive.
- Les années à quatre chiffres, dont `0000`, sont acceptées si le calendrier est valide. `9999-12-31` est accepté ; sa borne supérieure est `+010000-01-01T00:00:00.000Z`, conformément à l'ISO étendu de JavaScript. Ne pas imposer une limite d'année arbitraire.
- Les erreurs inattendues sont relancées, conformément au modèle de `src/routes/bookings.ts`. Ne pas les transformer en erreurs de saisie ou en créneaux libres.
- Les données et identifiants restent en mémoire et sont perdus au redémarrage.

## Sources et état de départ

Lire avant toute modification : `AGENTS.md`, `.agents/skills/salles-api/SKILL.md`, `src/lib/AGENTS.md`, les fichiers concernés ci-dessous et les tests existants.

La branche constatée est `tp2-reparation`. Préserver les changements préexistants des autres intervenants ; ne jamais revenir globalement à `HEAD`. Les copies de référence de l'orchestrateur sont dans `/tmp/salles-availability-baseline/` (`rooms.ts`, `validate.ts`, `validate.spec.ts`, `http.ts`, `README.md`, `store.ts`) pour distinguer le travail nouveau du travail existant.

L'annonce fournie de typecheck, lint et tests unitaires verts (82 réussis, un skip) décrit l'état antérieur, pas la validation de cette fonctionnalité. Le contrôle strict et la couverture doivent être exécutés après implémentation.

Les rôles définissent des responsabilités ; le sandbox effectif reste l'autorité technique. Ce plan ne prétend pas apporter une isolation de chemins supplémentaire.

## Fichiers autorisés pour l'étape dev

| Fichier | Modification prévue |
|---|---|
| `src/lib/availability.ts` (nouveau) | Fonction pure de complément des occupations dans les bornes d'une journée, types de créneau et exports default + nommé compatibles |
| `src/lib/validate.ts` | Helper nommé de validation du jour exact, en conservant les helpers existants et le default actuel |
| `src/routes/rooms.ts` | Nouvelle route, recherche de salle, validation, appel du calcul et réponse JSON |
| `test/availability.spec.ts` (nouveau) | Tests unitaires du calcul et scénarios HTTP réels |
| `test/validate.spec.ts` | Tests directs du nouveau helper de jour |
| `test/http.ts` | Extension minimale des types de réponse pour `roomId`, `date` et `slots` |
| `README.md` | Contrat, exemple, journée UTC complète, erreurs et limite mémoire ; la ligne d'endpoint existe déjà |

Aucun changement de store, de package, de configuration ou de hook. Aucune dépendance supplémentaire n'est nécessaire.

## Étape 1 — implémentation bornée, confiée à un seul dev

Le dev possède exclusivement les sept fichiers applicatifs, de test et de documentation listés ci-dessus pour cette étape. Il charge le skill, prend en compte les changements des autres intervenants et ne délègue pas récursivement. Le plan lui est transmis par son chemin, intact.

1. Ajouter un helper pur de validation du jour à `validate.ts`. Vérifier le type chaîne, le format exact, puis le calendrier par comparaison avec une représentation UTC canonique. Éviter `Date.UTC(année, ...)` sans correction, car les années 0 à 99 y sont remappées. Retourner le jour validé sans altération. Utiliser `ValidationError` pour toutes les erreurs d'entrée prévues ; conserver le contrat de `requireDate`.
2. Créer `availability.ts` avec une fonction pure recevant les bornes UTC et les occupations, sans importer le store à l'exécution. Ramener chaque occupation à l'intersection avec la journée, exclure les intersections vides, trier une copie par début puis fin, et parcourir avec un curseur. Émettre un créneau si le prochain début dépasse le curseur, puis avancer le curseur au maximum de sa valeur et de la fin occupée. Émettre le complément final seulement s'il est positif. Ce calcul fusionne implicitement chevauchements, inclusions et contiguïtés.
3. Ajouter la route `/:id/availability` dans `rooms.ts`. Rechercher la salle en premier ; après validation du jour, construire les deux minuits UTC et calculer avec `bookingsForRoom(room.id)`. Renvoyer `{ roomId: room.id, date, slots }`. Intercepter uniquement `ValidationError` au niveau de la route et relancer toute autre erreur. Ne pas consommer un identifiant ni écrire dans le store.
4. Ajouter les tests ci-dessous avec les helpers de production. Étendre seulement les types nécessaires dans `test/http.ts`, sans changer son cycle de vie : `vi.resetModules()` avant chaque scénario HTTP et fermeture du serveur attendue ; aucun reset entre les requêtes d'un même scénario.
5. Compléter la documentation et exécuter les commandes de validation. Imports relatifs `.js`, un default principal dans chaque module lib, exports nommés compatibles, aucune JSDoc dans `src/lib/`. Respecter les conventions existantes ailleurs.

### Matrice minimale de tests

| Niveau | Cas et assertions |
|---|---|
| Validation unitaire | Jour ordinaire, 2024-02-29, 0000-02-29, 9999-12-31 acceptés sans altération ; années bissextiles de siècle vérifiées (2000 valide, 1900 invalide) ; absence, null, nombres, tableaux, objets, vide, espaces, format non strict, mois/jour hors calendrier et 2026-02-29 rejetés avec `ValidationError` |
| Calcul unitaire | Aucune occupation → journée entière ; occupation complète ou englobante → tableau vide ; réservations triées et non triées ; chevauchement, inclusion et adjacence ; occupations avant/après la journée et touchant exactement les bornes ; intersections traversant un ou deux minuits ; fractions de millisecondes conservées |
| Pureté unitaire | Tableau et objets d'occupation restent inchangés, y compris leur ordre ; un tableau/objets gelés peut être utilisé pour détecter les mutations ; export default identique à l'export nommé |
| HTTP de base | Salle connue libre → 200 et contrat exact ; fixture `salle-a` du 2026-10-05 → [00:00,09:00[ et [11:00,minuit suivant[ ; les réservations d'une autre salle n'influencent pas le résultat |
| HTTP erreurs | Salle inconnue → 404 avec jour valide, invalide ou absent ; salle connue → 400 pour date absente, vide, répétée (`date=...&date=...`), tableau (`date[]=...`), objet (`date[value]=...`), espaces encodés, format ou calendrier invalides |
| HTTP limites | Occupations à cheval sur minuit, bornes exactes, journée entière, plusieurs réservations non triées et millisecondes ; jour bissextile et changement d'année ; 0000 et 9999-12-31 avec borne supérieure ISO étendue |
| HTTP cycle de vie | Dans un même `withApi` : GET libre, POST réservation réussi, GET diminué, DELETE réussi, GET restauré. Comparer l'état/ordre des réservations avant et après GET et prouver que les GET ne consomment pas d'identifiants via les POST suivants |

Les chevauchements impossibles à créer par POST sont testés directement dans le calcul pur. Les scénarios HTTP peuplent leur store isolé avec les API existantes ou, si nécessaire pour établir un ordre non trié, avec ses exports existants sans modifier `src/store.ts`. Aucun placeholder ou nouveau skip.

## Étape 2 — revue indépendante, sans correction

Un reviewer charge le skill et examine le diff de cette fonctionnalité par rapport aux copies de référence. Il vérifie le contrat, les validations, le calcul des bornes et le complément, l'absence de mutation et de consommation d'identifiants, les erreurs inattendues, les tests et la portée des fichiers. Il ne modifie aucun fichier applicatif. Toute correction requise revient au dev avec un brief borné, puis les vérifications affectées sont rejouées.

## Étape 3 — test indépendant du logiciel exécuté

Un tester charge le skill, exécute les scénarios HTTP de production et relève les résultats. La revue seule ne satisfait pas cette étape. Le tester peut lancer l'application avec un port libre et exercer au minimum la fixture et les erreurs de requête :

```bash
PORT=3100 npm start
```

Dans un second terminal :

```bash
curl --fail-with-body 'http://127.0.0.1:3100/rooms/salle-a/availability?date=2026-10-05'
curl -i 'http://127.0.0.1:3100/rooms/salle-a/availability?date=2026-02-29'
curl -i 'http://127.0.0.1:3100/rooms/inconnue/availability'
```

Attendre respectivement 200 avec les deux créneaux de l'exemple, 400 et 404. Arrêter le processus démarré après le test. Les scénarios POST/GET/DELETE/GET sont exercés par les tests HTTP `withApi`, sans réinitialisation intermédiaire. Consigner toute commande empêchée et sa cause ; ne pas annoncer un succès non observé.

## Commandes de validation

Depuis la racine du dépôt, après l'étape dev :

```bash
npm run test:unit -- test/availability.spec.ts test/validate.spec.ts
npm run typecheck
npm run lint
npm run check
```

`npm run check` est le contrôle bloquant final : typecheck, lint, tous les tests Vitest, harness et couverture. Les seuils existants restent 90 % pour lignes/instructions/fonctions et 85 % pour branches. Le skip INFRA-198 reste justifié. Il n'existe aucune commande build à ajouter. Aucun hook Codex interactif n'est utilisé sans examen et approbation via `/hooks`.

## Critères de livraison

- Tous les cas de la matrice sont vérifiés par des appels aux fonctions de production ou au serveur réel ; JSON, statuts et bornes exacts sont assertés.
- La journée UTC complète est explicitement documentée ; sortie chronologique, maximale, sans créneau nul, conforme aux intervalles semi-ouverts et conservant les millisecondes.
- Aucune régression des helpers de timestamps ni des routes existantes ; état et identifiants inchangés par les GET.
- Revue indépendante et test HTTP effectif terminés, avec les limites éventuelles déclarées.
- `npm run check` se termine avec code 0 sans abaissement de seuils ni nouveau skip.
- Diff limité aux fichiers prévus pour cette fonctionnalité, préservation du travail antérieur et de `src/store.ts`, aucun ajout de dépendance ni push.
