---
description: Préparer une livraison vérifiée
agent: architect
---

Exécute npm run check sur l’état final et exige une revue indépendante. Si un contrôle échoue, retourne à dev. Présente ensuite le diff, les résultats et les limites. Ne committe et ne pousse que si l’utilisateur a explicitement demandé cette livraison et fourni le dépôt cible ; jamais vers le dépôt pédagogique original. Un ancien hook post-écriture ne garantit pas le dernier état. Ne pas utiliser git add -A aveuglément : exclure secrets, dépendances et fichiers temporaires.
