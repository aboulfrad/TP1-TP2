// Le signal post-écriture reste soft (INFRA-231) ; commit/CI utilisent --strict.
export const ChecksPlugin = async ({ $, directory }) => ({
  "tool.execute.after": async (input, output) => {
    if (!["edit", "write", "apply_patch"].includes(input.tool)) return;
    const file = input.args?.filePath ?? input.args?.path ?? "";
    const patch = input.args?.patchText ?? "";
    const relevant = /\.(ts|js|json|sh|ya?ml)$/.test(file)
      || /(?:src\/|test\/|package\.json|config\.|scripts\/|workflows\/)/.test(patch);
    if (!relevant) return;
    try {
      const result = await $`bash scripts/checks.sh`.cwd(directory).quiet().nothrow();
      const stdout = result.stdout?.toString() ?? "";
      const stderr = result.stderr?.toString() ?? "";
      output.output += "\n\n--- checks post-écriture (soft) ---\n" + stdout + stderr;
    } catch (error) {
      output.output += "\n\nCHECKS_FAILED : contrôle impossible : " + String(error);
    }
  }
});
