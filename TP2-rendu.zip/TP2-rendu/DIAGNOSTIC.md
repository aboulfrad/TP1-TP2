# TP2 — Diagnostic du dépôt salles-api

## Périmètre et méthode

Dépôt pédagogique : https://github.com/0xaitox/ai-tools-repo-malade, commit initial `ab57521d04c1ed026be1440bc4e4d58c61788a2a`. Branche locale `tp2-reparation`. Audit et mesures le 8 octobre 2026.

**Adaptation à Codex autorisée par le professeur, selon la confirmation de l’étudiant.** La chaîne OpenCode a été conservée et réparée ; sa génération n’est pas validée sans fournisseur connecté. Une tentative native initiale OpenCode n’avait pas pu générer. Les deux générations comparées sont des sessions neuves Codex CLI 0.160.0, modèle hérité `gpt-6.1-sol`, sans aide ni reformulation pendant leur exécution. Le premier essai travaille sur une copie séparée du commit initial, le second sur le harness réparé, où l’endpoint était encore absent.

Consigne identique dans les deux cas :

> Ajoute un endpoint GET /rooms/:id/availability?date=YYYY-MM-DD qui renvoie les créneaux libres d'une salle sur la journée demandée, avec ses tests.

Le premier essai a produit l’endpoint mais a travaillé directement, sans délégation aux six rôles. Les contrôles sont restés trompeurs : les tests prix/réservations étaient encore ignorés. Dans le second essai, les six rôles finder, explorer, planner, dev, reviewer et tester ont réellement été appelés ; le plan a été transmis par chemin, une revue indépendante et un test HTTP ont suivi. Voir [trace des rôles](preuves/apres-roles-contexte.json), [exécutions](preuves/apres-execution.json) et [résultats](preuves/apres-reponse.md).

## Problèmes démontrés et réparations

| Brique du cours | Symptôme constaté | Cause / fichier | Réparation et preuve |
|---|---|---|---|
| Rules / commandes | `npm test` annoncé échoue, code 1 ; `npm run build` aussi absent. | `AGENTS.md`, `package.json`. | Alias test réel ajouté ; documentation alignée. Aucun build artificiel pour un service exécuté par tsx. [test annoncé](preuves/test-annonce.json), [build annoncé](preuves/build-annonce.json). |
| Rules / contrat | Instructions promettent Result alors que validation et route utilisent throw/catch ; imports de facturation par défaut absents. | `AGENTS.md`, `src/lib/AGENTS.md`, helpers. | Décrire `ValidationError` et les erreurs inattendues réelles ; rétablir les defaults compatibles sans supprimer les exports nommés. Les règles locales priment. |
| Droits finder | Le finder ne peut même pas lire `src/app.ts`. | `.opencode/agent/finder.md` : wildcard deny placé en dernier. | Wildcard d’abord, autorisations précises ensuite. Liste réellement résolue par OpenCode 1.18.35 et évaluation du dernier matcher : read deny → allow, edit reste deny. [permissions avant/après](preuves/permissions-resolues.json). |
| Subagents / orchestration | Planner déclaré primary ; tester omis de la chaîne principale ; aucun rôle spécialisé appelé dans l’essai Codex initial. | `.opencode/agent/planner.md`, `architect.md`, configurations OpenCode initiales. L’adaptation à un autre client relève du choix autorisé, pas d’un défaut du dépôt. | Planner subagent ; six rôles joignables ; définitions `.codex/agents/` ajoutées et appelées dans la session finale. [avant](preuves/avant-roles-contexte.json), [après](preuves/apres-roles-contexte.json). |
| Droits / séparation | Architect et explorer peuvent modifier l’application ; reviewer peut corriger ce qu’il juge ; dev délègue récursivement ; shell du tester unrestricted. | `.opencode/agent/*.md`. | Orchestration et revue sans édition ; explorer limité aux notes, planner aux plans, tester au scratch ; dev task deny ; bash limité. Profils Codex read-only pour les rôles de lecture. Prompts et permissions d’outil ne sont pas une isolation universelle des chemins. [permissions résolues](preuves/permissions-resolues.json). |
| Commands / Git | `/ship` fait git add global, commit et push sans contrôle final ni revue. | `.opencode/command/ship.md`. | Vérification stricte, revue et diff avant préparation du commit ; aucun push automatique vers le dépôt pédagogique. |
| MCP / contexte | Six connecteurs activés ; certains sont indisponibles ici et aucun n’est utilisé par cette API en mémoire. Les trois serveurs locaux découvrables exposent 75 outils, 120242 octets de descripteurs JSON. | `opencode.json`. | Déclarations conservées et désactivées par défaut ; syntaxe du token corrigée vers `{env:SALLES_MCP_TOKEN}`. Sonde initialize/tools-list sans token, aucun appel métier. Le byte count n’est pas un comptage de tokens. [sondes](preuves/mcp-sondes.json). |
| Skills | Conventions répétées et chaîne sans skill projet commun. L’absence seule n’est pas un bug. | Absence de skill projet initial. | Choix de packager `.agents/skills/salles-api/SKILL.md` pour les six spécialistes et les deux clients, effectivement chargé lors du second essai ; sans ajouter de service externe. |
| Hooks / visibilité | Hook OpenCode ignore apply_patch et configurations, n’affiche que stdout. | `.opencode/plugin/checks.js`. | edit/write/apply_patch et fichiers de contrôle couverts ; stdout et stderr, erreurs de lancement visibles. Test Node avec shell simulé réellement exécuté. `input.args` est correct et conservé. |
| Hooks / checkpoint | Le post-check retourne 0 malgré des contrôles rouges. Cela est délibéré ; en revanche il n’existe pas de filet strict équivalent avant livraison. | `scripts/checks.sh`, hooks / CI. | Garder soft selon INFRA-231 ; ajouter `--strict`, utilisé par Git, CI et Stop Codex. Tests : npm simulé code 17 donne soft 0 + CHECKS_FAILED, strict 1. |
| Hooks Codex | Première adaptation : Stop depuis `src/` retourne silencieusement {}. | `.codex/hooks/checks.py`, racine déduite de cwd. | Revue indépendante a reproduit le défaut ; racine déduite de l’emplacement du hook. Test depuis un sous-dossier : échec bloque la fin, continuation échouée explicitée, réussite signalée. Cinq tests harness verts, dont la protection du hook Git d’un dépôt parent. |
| Hooks automatiques | Présence d’un fichier ne prouve pas l’exécution. | Déclenchement et confiance des hooks. | Traces natives de PostToolUse Bash/apply_patch et Stop strict, code 0 final. Hooks examinés puis autorisés ponctuellement pour cette automatisation, sans changer le sandbox système. [événements réels](preuves/hooks-codex-session.jsonl). |
| Lint / types | Lint et typecheck verts, mais lint sans règles utiles, strict désactivé et `@ts-nocheck` sur le prix. | `eslint.config.js`, `tsconfig.json`, `src/lib/price.ts`. | Règles recommandées TypeScript, ban-ts-comment, no-explicit-any, égalité stricte ; types stricts ; suppression du ts-nocheck. Aucun affaiblissement des seuils. [vert initial](preuves/lint-actuel.json), [types initiaux](preuves/types-actuels.json), [contrôle final](preuves/check-final.txt). |
| Tests / découverte | 18 cas sources : seuls 9 découverts, dont 5 passent et 4 ignorés. Les neuf cas `.test.ts` sont invisibles. | `vitest.config.ts`, `test/price.test.ts`, `bookings.test.ts`. | Renommer en `.spec.ts`, conserver la convention. Exécution complète exploratoire du code original : 12 passent, **2 échouent**, 4 ignorés. [sortie complète](preuves/tests-originaux-tous.txt). |
| Tests / valeur | Store testé via un double local ; deux placeholders `expect(true)` ; adjacency ignorée. | `test/store.spec.ts`, `overlap.spec.ts`. | Vrais imports du store ; assertions métier pour inclusion, identité, adjacency et identifiants ; tests HTTP avec état isolé. Le store de production est inchangé. |
| Tests / mesures | Vert initial avec peu de couverture et mutants survivants ; overlap atteint 100 % des lignes malgré l’erreur de bornes. | Suite initiale trop faible. | Couverture V8 sur tous les src hors bootstrap serveur, seuils 90/90/90/85 ; cinq mutants sémantiques contrôlés sur copies jetables. Les témoins sans mutation sont verts. [mutations originales](preuves/mutations-originales.json), [finales](preuves/mutations-apres.json). |
| Bug détecté / prix | Test week-end renvoie **"5020"** au lieu de **70**. | `src/lib/price.ts` : surcharge chaîne "20", concaténation avec le tarif. | Surcharge numérique ; tests réels semaine/week-end/fractions ; HTTP final labo deux heures : **100 numérique**. [échec original](preuves/tests-originaux-tous.txt), [HTTP final](preuves/http-final.json). |
| Bug détecté / intervalle | Réservation commençant exactement à la fin de la précédente : **409 au lieu de 201**. | `src/lib/overlap.ts` utilise <= pour des intervalles `[début, fin[`. | Comparaisons strictes < ; tests bout-à-bout et HTTP. [échec original](preuves/tests-originaux-tous.txt), [HTTP final](preuves/http-final.json). |
| Validation / contrat | `2026-02-30T09:00:00Z` et offset non UTC acceptés par le validateur original. | `src/lib/validate.ts` vérifie seulement Date.parse. | Format UTC et comparaison calendaire canonique ; validation d’objet explicite ; jour YYYY-MM-DD validé pour availability. [appels originaux et réparés](preuves/validation-calendrier.json). |
| API / erreurs | JSON syntaxiquement invalide n’est pas présenté comme erreur JSON de l’API. | Parser Express sans handler dédié dans `src/app.ts`. | Handler ciblé pour SyntaxError entity.parse.failed : 400 JSON ; erreurs inattendues transmises. Avant : 400 text/html confirmé sur le serveur initial ; après : 400 JSON vérifié. [Réponse originale](preuves/json-invalide-original.json) et [réponses finales](preuves/http-final.json). |
| CI / Git | CI n’exécute que lint ; tests commentés ; fichier Husky présent mais non installé, core.hooksPath absent. | `.github/workflows/ci.yml`, `.husky/pre-commit`, scripts npm. | CI npm ci + check complet sur push/PR ; hook `.githooks/pre-commit` installé par prepare, avec conservation d’un hook existant et protection des dépôts parents. [Git avant](preuves/git-hooks-avant.json) ; core.hooksPath=.githooks confirmé localement. La CI distante reste à exécuter après push. |
| Dépendances | Audit initial : 7 vulnérabilités, dont 2 critiques. | Versions résolues dans le lockfile initial. | Mise à jour propre, Vitest et coverage-v8 5.0.3 alignés ; Node compatible documenté ; audit final 0. Pas de force ni legacy-peer-deps. [avant](preuves/audit-dependances-avant.json), [après](preuves/audit-dependances-apres.json). |
| Git / environnement | `.env` est suivi dans le snapshot courant. | Index Git initial. | Retiré du suivi courant, ignoré ; `.env.example` vide ajouté. ZIP sans .env réel ni dépendances installées. L’historique pédagogique hérité n’est pas réécrit. |

## État réellement observé des MCP

| Connecteur | Sonde locale sans authentification | Décision |
|---|---|---|
| GitHub | initialize/tools-list réussis, 26 outils ; aucune opération GitHub testée | Désactivé tant qu’inutile à l’API |
| Notion | initialize/tools-list réussis, 24 outils ; réponse de liste 81 940 octets ; tampon de la sonde augmenté après dépassement | Désactivé ; pas de faux diagnostic « serveur mort » |
| Playwright | initialize/tools-list réussis, 25 outils ; aucune navigation métier exécutée par ce MCP | Désactivé par défaut |
| Slack | Processus termine sans réponse, configuration/auth non fournie | Indisponible dans cet environnement ; désactivé |
| salles-db | Adresse interne ne se résout pas ici ; aucun Authorization envoyé | Pas de dépendance requise pour le store en mémoire |
| Sentry | HTTP 403, protection du serveur distant ; aucun token envoyé | Pas de nouvelle tentative ni contournement |

Ces résultats ne prouvent pas une panne globale ni une authentification métier valide. Les MCP globaux de Codex restent distincts des six déclarations du projet OpenCode.

## Mesures avant / après

Trois états sont distingués pour ne pas confondre l’état brut du dépôt et le résultat de la première génération.

| Mesure | Commit initial brut | Après premier essai exact | Rendu réparé / second essai |
|---|---:|---:|---:|
| Tests Vitest passants | 5 | 47 | 141 |
| Skips découverts | 4 | 4 | 1, INFRA-198 |
| Couverture lignes | 8.98 % | 47.45 % | 97.77 % |
| Couverture instructions | 8.6 % | 47.54 % | 97.85 % |
| Couverture branches | 5.71 % | 37.25 % | 95.45 % |
| Couverture fonctions | 4.76 % | 46.15 % | 100 % |
| Mutants ciblés détectés | 1/5 (20 %) | 3/5 (60 %) | 5/5 (100 %) |
| Tests harness Node | Non présents | Non présents | 5 passent |
| Rôles spécialisés appelés dans la génération | — | 0 | 6 |

La suite initiale configurée a réellement tourné avec Vitest 2.1.9. Les sondes de couverture, de mutation et de découverte élargie utilisent un instrument commun Vitest/V8 5.0.3 sur les copies de sources correspondantes ; elles ne prétendent pas être une couverture déjà configurée dans le dépôt initial. Seul `src/server.ts`, bootstrap d’écoute, est exclu ; app, routes et store sont inclus. Cinq mutants manuels ne constituent pas une campagne exhaustive Stryker. Les témoins verts empêchent de compter un défaut d’environnement comme mutant détecté.

### Contexte effectivement consommé

| Mesure de la session principale | Premier essai | Second essai |
|---|---:|---:|
| Entrées cumulées sur les appels au modèle | 2,244,070 | 1,694,412 |
| Dont entrées en cache | 2,127,104 | 1,608,704 |
| Entrées hors cache, par soustraction | 116,966 | 85,708 |
| Plus grande entrée d’un appel observé | 66,278 | 53,515 |
| Sorties cumulées | 17,919 | 6,810 |

Les cumuls incluent les relectures du contexte à chaque appel ; **ce n’est pas une fenêtre de plusieurs millions de tokens**. Le maximum par appel est une autre mesure. Ces chiffres concernent la session principale, sans somme des consommations privées des spécialistes, et ne sont pas une facture. Le modèle est identique mais il n’y a qu’un essai par état : pas de benchmark statistique ni causalité isolée. Le premier essai a aussi subi des lectures très lentes de node_modules sur le Bureau ; les dépendances du second ont été installées proprement sur un dossier temporaire local. Cette difficulté de fichiers est un facteur d’environnement, pas une faute attribuée au harness. [mesures avant](preuves/avant-roles-contexte.json), [après](preuves/apres-roles-contexte.json).

## Vérification finale et choix conservés

- `npm run check` : code 0, également après `npm ci` dans une copie indépendante sans .git ni node_modules ; lint, types stricts, 141 tests + 1 skip, cinq tests harness et seuils de couverture passent. [Sortie réellement produite](preuves/check-final.txt) ; [installation propre](preuves/installation-propre.json).
- Test indépendant dans la chaîne : rapport du tester de 54 requêtes / 138 assertions, réussite, serveur arrêté. Contrôle indépendant complémentaire de l’orchestrateur : dix requêtes enregistrées au serveur démarré par npm start, statuts et corps assertés, processus arrêté. [HTTP réel](preuves/http-final.json).
- Store `src/store.ts` gelé selon INFRA-140 : aucune modification du fichier. Son état et ses identifiants sont testés réellement ; aucune persistance inventée.
- Le skip historique INFRA-198 reste, car la fixture réelle n’existe pas. Les deux placeholders et le skip de bornes injustifié ont été remplacés par des assertions utiles.
- Convention `.spec.ts` conservée ; pas d’élargissement silencieux de la règle de nommage.
- Absence de JSDoc dans `src/lib/` conservée selon la règle locale. Aucun faux positif sur `input.args` du hook after, confirmé par le SDK installé.
- Le soft exit 0 reste selon INFRA-231. Le strict est un checkpoint distinct ; une sortie soft n’est pas assimilée à un succès des tests.
- Le lockfile était déjà suivi dans le dépôt initial : son absence n’est pas un problème signalé. Il est mis à jour et conservé.
- Les dates de disponibilité portent sur une journée UTC complète : aucune règle d’ouverture n’était donnée. Les GET ne mutent pas les réservations ; POST/DELETE sont reflétés immédiatement.
- Branche de réparation locale et dépôt d’origine conservés ; aucun push vers le dépôt pédagogique.

## Captures et état de remise

**Code réparé et vérifié localement ; les deux captures des résultats sont incluses. Le dépôt personnel reste à pousser.**

Le dossier [captures](captures/README.md) contient une capture du démarrage où l’endpoint était absent, puis deux vraies captures macOS fournies par l’étudiant : [avant](captures/02-session-avant.png) (47 tests réussis, 4 désactivés) et [après](captures/03-session-apres.png) (141 tests réussis, un test historique désactivé et validation HTTP). Elles montrent les résultats des deux générations ; la consigne exacte n’y est pas visible, mais est conservée dans les traces des sessions. Aucune image reconstruite. Les preuves texte/JSON sont complémentaires.

Le ZIP contient uniquement le dépôt de rendu, hors .git, node_modules, caches, .env réel, outillage temporaire et autres TP. **Le push demandé par le sujet reste à réaliser.** L’URL du dépôt GitHub personnel est à fournir ; la CI GitHub ne sera confirmée qu’après son exécution sur ce dépôt.

## Sources techniques consultées

- [OpenCode — permissions](https://opencode.ai/docs/permissions/) : dernière règle correspondante ; comportement confirmé par la liste locale résolue et le runtime installé.
- [OpenCode — plugins](https://opencode.ai/docs/plugins/) : tool.execute.after, confirmé par les types du SDK 1.18.35.
- [Codex — agents spécialisés](https://developers.openai.com/codex/subagents) et [hooks](https://developers.openai.com/codex/hooks) : configuration adaptée puis exécutée et instrumentée localement.
