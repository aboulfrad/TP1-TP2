# salles-api — TP2

API Express / TypeScript de réservation de salles. [DIAGNOSTIC.md](DIAGNOSTIC.md) présente l’audit, les preuves et les limites.

## Installation

```bash
npm ci
npm run check
npm start
```

Node.js 22.12+ (branche 22), 24 ou 26+. La CI utilise Node 22. `npm ci` installe `.githooks/pre-commit`, en conservant un éventuel hook déjà configuré. Port 3000 (`PORT` configurable). Données en mémoire, perdues au redémarrage. Aucun compte ni fichier `.env` nécessaire pour l’API locale.

| Commande | Effet |
|---|---|
| `npm test` | Tests Vitest unitaires et HTTP |
| `npm run lint` | ESLint et règles TypeScript |
| `npm run typecheck` | Compilation stricte sans émission |
| `npm run test:coverage` | Couverture V8 avec seuils |
| `npm run test:harness` | Tests des contrôles et du plugin |
| `npm run check` | Tous les contrôles, échec bloquant |
| `npm run check:soft` | Contrôles post-écriture informatifs ; code 0 selon INFRA-231 |
| `node scripts/mutation.mjs . rapport.json` | Cinq mutants ciblés dans des copies temporaires |

## API

| Méthode | Route | Rôle |
|---|---|---|
| GET | `/health` | Sonde |
| GET | `/rooms` | Catalogue |
| GET | `/rooms/:id` | Salle et réservations |
| GET | `/rooms/:id/availability?date=YYYY-MM-DD` | Créneaux libres d’une journée UTC |
| GET | `/bookings?roomId=` | Réservations |
| POST | `/bookings` | Création |
| DELETE | `/bookings/:id` | Annulation |

Intervalles semi-ouverts `[début, fin[` : réservations adjacentes autorisées. Dates de réservation ISO 8601 UTC. Prix numériques. Validation de POST (y compris salle inconnue) : 400 ; salle inconnue sur GET : 404 ; conflit : 409.

`GET /rooms/:id/availability?date=YYYY-MM-DD` renvoie les créneaux libres triés et maximaux sur la journée UTC complète `[00:00, minuit du lendemain[`, sans horaires d'ouverture supplémentaires. Les bornes sont des chaînes ISO 8601 UTC avec millisecondes ; une journée entièrement réservée renvoie `slots: []`.

```json
{
  "roomId": "salle-a",
  "date": "2026-10-05",
  "slots": [
    { "startsAt": "2026-10-05T00:00:00.000Z", "endsAt": "2026-10-05T09:00:00.000Z" },
    { "startsAt": "2026-10-05T11:00:00.000Z", "endsAt": "2026-10-06T00:00:00.000Z" }
  ]
}
```

Une salle inconnue renvoie `404 {"error":"salle inconnue"}` avant la validation du jour. Pour une salle connue, `date` doit être une unique chaîne exacte représentant un jour calendaire valide ; absence, répétition, espaces ou date impossible renvoient `400 {"error": ...}`. Les années `0000` à `9999` sont acceptées ; la borne finale de `9999-12-31` est `+010000-01-01T00:00:00.000Z`. Les consultations ne modifient ni réservations ni identifiants ; leur résultat reflète les données en mémoire, perdues au redémarrage.

## Agents et contrôles

Adaptation à Codex autorisée par le professeur, selon la confirmation de l’étudiant. Six rôles dans `.codex/agents/` : finder, explorer, planner, dev, reviewer, tester. L’orchestrateur suit `AGENTS.md`, le plan reste sur disque et dev seul modifie le code applicatif. Le skill commun est `.agents/skills/salles-api/SKILL.md`.

Dans Codex, examiner et approuver les hooks avec `/hooks`. Ils contrôlent les modifications et exécutent un checkpoint strict à la fin. L’automatisation peut autoriser ponctuellement ces hooks après examen ; cela ne modifie pas les permissions système. Les agents de lecture utilisent le sandbox read-only.

La chaîne OpenCode est conservée et réparée dans `.opencode/` et `opencode.json`, avec héritage du modèle configuré par l’utilisateur. La génération OpenCode n’est pas validée sans fournisseur connecté ; les essais Codex ne la prouvent pas. Les six MCP optionnels sont désactivés, cette API étant en mémoire. `.env.example` contient des emplacements vides pour une éventuelle réactivation ; ne pas committer de token.

Le store reste gelé (INFRA-140). Le skip historique INFRA-198 reste justifié par sa fixture manquante. `/ship` exige contrôles et revue, sans push automatique au dépôt pédagogique.
