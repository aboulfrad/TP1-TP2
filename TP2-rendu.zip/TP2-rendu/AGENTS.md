# salles-api — conventions vérifiées

Service Express + TypeScript. Les données et identifiants restent en mémoire : ne pas prétendre à une persistance après redémarrage.

## Commandes réelles

- `npm ci` : installation reproductible et installation du hook Git local.
- `npm start` : API sur le port 3000 (PORT configurable).
- `npm test` / `npm run test:unit` : tests Vitest `test/**/*.spec.ts`.
- `npm run lint`, `npm run typecheck`, `npm run test:coverage`, `npm run test:harness` : contrôles distincts.
- `npm run check` : contrôle complet bloquant avant commit et dans la CI.
- Pas de commande build : le service est lancé par tsx ; typecheck vérifie TypeScript sans émettre de dist.

## Conventions et périmètres

1. JSDoc minimale sur les fonctions exportées, sauf dans `src/lib/` dont les instructions locales priment, et le store legacy gelé.
2. La validation utilise `ValidationError`, interceptée centralement dans la route. Ne pas imposer une migration Result : elle casserait le contrat actuel. Ne jamais masquer une erreur inattendue.
3. Dates publiques en chaînes ISO 8601 UTC ; objets Date réservés aux calculs internes.
4. Un module pur par responsabilité dans src/lib ; export default principal et exports nommés compatibles ; imports relatifs `.js`.
5. Tests nommés `.spec.ts`, vrais appels au code de production. Aucun placeholder ni skip sans justification précise. Le skip INFRA-198 reste tant que sa vraie fixture manque.
6. Ne pas toucher `src/store.ts` : le remplacement relève d’INFRA-140. Isoler son état dans les tests par réinitialisation du graphe des modules.
7. Toute dépendance supplémentaire est motivée dans le plan ou le diagnostic. Les outils de mesure et mises à jour de sécurité du TP sont autorisés et consignés.
8. Ne pas lire de fichiers `.env` réels ni de tokens. `.env.example` est un exemple vide ; les prompts et permissions de lecture ne remplacent pas une isolation OS des secrets.
9. Branche de travail, jamais main. Aucun push vers le dépôt pédagogique original.

## Chaîne d’agents adaptée à Codex

L’utilisateur a confirmé l’autorisation du professeur pour Codex. `.codex/agents/` fournit les six rôles ; `.opencode/agent/` conserve une chaîne OpenCode réparée. Les tests Codex ne constituent pas une exécution OpenCode.

Pour une tâche qui ajoute ou modifie une fonctionnalité, déléguer les recherches à finder/explorer, le plan à planner, chaque étape d’implémentation à dev, puis une vérification indépendante à reviewer et un test HTTP à tester. Fournir des briefs autonomes avec chemins, critères et commandes exacts. L’orchestrateur ne modifie pas le code applicatif. Ne lancer jamais deux dev sur les mêmes fichiers. Les experts de lecture ne corrigent pas le diff.

Tous les spécialistes chargent le skill `salles-api` avant leur travail. Le plan est transmis par chemin, sans réécriture de son contenu. Le dev ne délègue pas récursivement. La revue ne remplace pas le test du logiciel exécuté. Signaler franchement les contrôles qui n’ont pas pu tourner.

Les hooks Codex doivent être examinés et approuvés via `/hooks` avant utilisation interactive. Les contrôles post-écriture restent informatifs ; la CI et le hook pre-commit utilisent le mode strict. Les prompts sont des consignes de rôle, pas une isolation OS : le sandbox hérité reste l’autorité technique.
