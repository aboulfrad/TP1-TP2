Endpoint ajouté dans [rooms.ts](/Users/abdelraouf.boulfrad/Desktop/BUT3/IA/.travail-tp2/avant/src/routes/rooms.ts:11).

`GET /rooms/:id/availability?date=YYYY-MM-DD` renvoie `{ roomId, date, slots: [{ startsAt, endsAt }] }`.

- Journée complète en UTC, fin exclue.
- Réservations chevauchantes, contiguës et traversant minuit prises en compte.
- Date invalide ou absente : **400** ; salle inconnue : **404**.

**42 nouveaux tests** ajoutés. Validation réussie : **47 tests passent**, 4 préexistants désactivés ; TypeScript et lint passent également.