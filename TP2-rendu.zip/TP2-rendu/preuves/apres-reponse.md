Endpoint ajouté dans [rooms.ts](/Users/abdelraouf.boulfrad/Desktop/BUT3/IA/tp2-repo-malade/src/routes/rooms.ts:12).

- Réponse : `{ roomId, date, slots: [{ startsAt, endsAt }] }`.
- Journée UTC complète, créneaux triés en ISO UTC.
- Date invalide : **400** ; salle inconnue : **404**.
- **59 tests ajoutés**, couvrant minuit, chevauchements, millisecondes et création/annulation.

Validation : `npm run check` réussi — **141 tests passent**, 1 skip legacy. Revue sans anomalie et test HTTP indépendant réussi : **54 requêtes, 138 assertions**.