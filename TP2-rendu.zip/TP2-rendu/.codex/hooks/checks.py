"""Checks after edits; strict check at Stop. No trust state or credentials modified."""
from pathlib import Path
import json, subprocess, sys, hashlib, tempfile, datetime

def main():
    event = json.load(sys.stdin)
    root = Path(__file__).resolve().parents[2]
    kind = event.get('hook_event_name')
    tool = event.get('tool_name', '')
    if kind == 'PostToolUse' and tool not in ('Bash', 'apply_patch', 'Edit', 'Write'):
        print('{}'); return
    if not (root / 'scripts/checks.sh').exists():
        print('{}'); return
    strict = kind == 'Stop'
    digest = hashlib.sha256()
    files = list((root / 'src').rglob('*.ts')) + list((root / 'test').rglob('*'))
    files += [root / name for name in ('package.json', 'package-lock.json', 'tsconfig.json', 'eslint.config.js', 'vitest.config.ts', 'scripts/checks.sh', '.github/workflows/ci.yml')]
    for path in sorted(files):
        if path.is_file():
            digest.update(str(path.relative_to(root)).encode()); digest.update(path.read_bytes())
    fingerprint = digest.hexdigest()
    state = Path(tempfile.gettempdir()) / ('tp2-checks-' + hashlib.sha256(str(root).encode()).hexdigest()[:20] + '.json')
    if not strict and state.exists() and json.loads(state.read_text()).get('fingerprint') == fingerprint:
        print('{}'); return

    process = subprocess.run(['bash', 'scripts/checks.sh'] + (['--strict'] if strict else []), cwd=root, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    state.write_text(json.dumps({'fingerprint': fingerprint, 'exit_code': process.returncode}))
    trace = root / '.opencode/scratch/codex-hook-events.jsonl'
    trace.parent.mkdir(parents=True, exist_ok=True)
    with trace.open('a') as stream:
        stream.write(json.dumps({'date_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'session_id': event.get('session_id'), 'event': kind, 'tool': tool, 'strict': strict, 'exit_code': process.returncode, 'signal': 'CHECKS_FAILED' if 'CHECKS_FAILED' in process.stdout else 'CHECKS_OK'}) + '\n')
    output = process.stdout
    message = '\n'.join(output.splitlines()[-65:])
    if strict:
        if process.returncode and event.get('stop_hook_active'):
            print(json.dumps({'continue': False, 'systemMessage': 'CHECKS_FAILED : contrôles encore rouges après continuation ; livraison non validée.\n' + message}, ensure_ascii=False))
        elif process.returncode:
            print(json.dumps({'decision': 'block', 'reason': 'Contrôles finaux rouges : corriger ou signaler précisément le blocage.\n' + message}, ensure_ascii=False))
        else:
            print(json.dumps({'systemMessage': 'CHECKS_OK : vérification finale bloquante exécutée.'}))
    else:
        print(json.dumps({'hookSpecificOutput': {'hookEventName': 'PostToolUse', 'additionalContext': message}}, ensure_ascii=False))

if __name__ == '__main__':
    main()
