import { execFileSync } from "node:child_process";
import { resolve } from "node:path";

try {
  const root = execFileSync("git", ["rev-parse", "--show-toplevel"], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trim();
  if (resolve(root) !== resolve(process.cwd())) {
    console.log("Sous-dossier d’un autre dépôt : hook du parent conservé ; npm run check reste disponible.");
    process.exit(0);
  }
} catch {
  console.log("Archive sans .git : hook Git non installé ; npm run check reste disponible.");
  process.exit(0);
}
let existing = "";
try { existing = execFileSync("git", ["config", "--get", "core.hooksPath"], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }).trim(); } catch { /* core.hooksPath absent : installation normale. */ }
if (existing && existing !== ".githooks") {
  console.log(`Hook existant conservé (${existing}) ; intégrer npm run check avant commit.`);
} else {
  execFileSync("git", ["config", "--local", "core.hooksPath", ".githooks"]);
  console.log("Hook Git local activé : .githooks/pre-commit.");
}
