#!/usr/bin/env bash
# Mode soft pour l’agent, mode strict pour commit/CI : même signal, sorties distinctes.
set -u
status=0
checks="typecheck lint test:unit"
if [ "${1:-}" = "--strict" ]; then checks="$checks test:harness test:coverage"; fi
for check in $checks; do
  echo "--- $check"
  npm run --silent "$check" || status=1
done
if [ "$status" -ne 0 ]; then
  echo "CHECKS_FAILED : au moins un contrôle est rouge" >&2
else
  echo "CHECKS_OK : tous les contrôles sont verts"
fi
if [ "${1:-}" = "--strict" ]; then exit "$status"; fi
exit 0
