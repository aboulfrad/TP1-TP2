import { mkdtempSync, cpSync, mkdirSync, readFileSync, writeFileSync, rmSync, existsSync, symlinkSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { spawnSync } from "node:child_process";

// Mutations bornées de code existant, en copies jetables : jamais sur le store de travail.
const source = resolve(process.argv[2] ?? ".");
const output = process.argv[3];
const dependencyRoot = resolve("node_modules");
const cli = join(dependencyRoot, "vitest/vitest.mjs");
const mutations = [
  { name: "recherche de salle supprimée", file: "src/store.ts", from: 'return rooms.find((r) => r.id === id);', to: "return undefined;" },
  { name: "filtrage des réservations supprimé", file: "src/store.ts", from: 'return bookings.filter((b) => b.roomId === roomId);', to: "return [];" },
  { name: "identifiants non incrémentés", file: "src/store.ts", from: "seq += 1;", to: "seq += 0;" },
  { name: "tarif de base annulé", file: "src/lib/price.ts", from: "room.hourlyRate * hoursBetween(startsAt, endsAt)", to: "0 * hoursBetween(startsAt, endsAt)" },
  { name: "chevauchement jamais détecté", file: "src/lib/overlap.ts", from: /return a1 <=? b2 && b1 <=? a2;/, to: "return false;" }
];

function run(mutation) {
  const temp = mkdtempSync(join(tmpdir(), "tp2-mutant-"));
  try {
    for (const dir of ["src", "test"]) cpSync(join(source, dir), join(temp, dir), { recursive: true });
    // Le nommage de la suite du dépôt source est conservé, donc les tests cachés restent cachés au baseline.
    writeFileSync(join(temp, "package.json"), '{"type":"module"}\n');
    // Les copies de sources sont indépendantes ; les dépendances sont partagées.
    symlinkSync(dependencyRoot, join(temp, "node_modules"), "dir");
    if (mutation) {
      const path = join(temp, mutation.file); const text = readFileSync(path, "utf8");
      const next = text.replace(mutation.from, mutation.to);
      if (text === next) throw new Error(`Mutation non applicable : ${mutation.name}`);
      writeFileSync(path, next);
    }
    const config = readFileSync(join(source, "vitest.config.ts"), "utf8");
    // Éviter seuils/caches/parallelisme pour mesurer uniquement la détection des assertions.
    const include = config.includes('"test/**/*.spec.ts"') ? "test/**/*.spec.ts" : "test/**/*.{spec,test}.ts";
    writeFileSync(join(temp, "vitest.config.mjs"), `export default { test: { include: [${JSON.stringify(include)}], maxWorkers: 1, environment: 'node' } };\n`);
    const result = spawnSync(process.execPath, [cli, "run", "--config", join(temp, "vitest.config.mjs")], { cwd: temp, encoding: "utf8", timeout: 90000 });
    if (result.error) throw result.error;
    return { mutant: mutation?.name ?? "suite témoin sans mutation", exit_code: result.status, sortie: result.stdout + result.stderr };
  } finally { rmSync(temp, { recursive: true, force: true }); }
}

if (!existsSync(join(source, "src/store.ts"))) throw new Error("Dépôt source absent");
const control = run();
if (control.exit_code !== 0) { console.error(control.sortie); throw new Error("Suite témoin rouge : score non interprétable"); }
const results = mutations.map((mutation) => { const result = run(mutation); console.log(result.mutant + " : " + (result.exit_code === 0 ? "SURVIVANT" : "DÉTECTÉ")); return result; });
const killed = results.filter((x) => x.exit_code !== 0).length;
const report = { methode: "Cinq mutants manuels ciblés, pas une campagne exhaustive Stryker", source, control, mutations: results, detectes: killed, total: results.length, score: killed / results.length * 100 };
if (output) writeFileSync(output, JSON.stringify(report, null, 2) + "\n");
console.log(`Score ciblé : ${killed}/${results.length} (${report.score}%)`);
