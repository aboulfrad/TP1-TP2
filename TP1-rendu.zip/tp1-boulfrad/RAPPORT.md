# TP1 — Faire parler une API que personne ne documente

Reprise du TP le 8 octobre 2026. Codex est utilisé avec l’autorisation du professeur rapportée par l’étudiant. Deux nouvelles sessions sans historique ont été exécutées : une sans skill, puis une avec skill. L’état du serveur n’a pas été remis à zéro ; les anciens prêts restent présents.

## 1. Connecter le serveur MCP

Le serveur répond et expose 12 outils : `list_books`, `count_books`, `get_book`, `search_books`, `list_members`, `get_member`, `list_loans`, `get_member_fees`, `create_loan`, `delete_loan`, `list_missions`, `get_mission`.

La configuration Codex utilise la variable `BIBLIO_TOKEN`. Le token est conservé hors du rendu dans un fichier privé ignoré. La configuration [opencode.json](opencode.json) est aussi fournie sans secret, avec la substitution documentée par [OpenCode](https://opencode.ai/docs/mcp-servers/). Aucun lancement sous OpenCode n’est revendiqué.

Test réel : `get_book({"book_id":"BK-1042"})` renvoie notamment `ok:true`, le titre « Le Dernier de verre », l’auteur Karim Barbier et `copies:4`. Voir [la réponse brute complète](preuves/lecture-brute.json) et [la liste des outils](preuves/connexion.json).

[Capture 1 : serveur connecté et 12 outils exposés](captures/01-outils-mcp.png). Capture réelle fournie par l’étudiant, conservée sans modification.

[Capture 2 : appel exact et réponse JSON native complète](captures/02-lecture-get-book.png). Capture réelle fournie par l’étudiant, conservée sans modification : les détails de bibliotheque.get_book sont dépliés et montrent tous les champs de la réponse.

### Les cinq énoncés exacts

Ils ont été relus sur le serveur avec `get_mission`, et non reconstitués : [réponses originales](preuves/enonces.json).

**M1 — Inventaire**

> Le conseil municipal demande le nombre exact d'ouvrages détenus par la bibliothèque, et la répartition par genre. Donne les chiffres et explique comment tu les as obtenus.

**M2 — Le retardataire**

> Identifie l'emprunt le plus en retard actuellement : quel adhérent, quel ouvrage, et combien de jours de retard exactement. Donne aussi le montant dû par cet adhérent.

**M3 — La réinscription**

> Enregistre un nouvel emprunt pour l'adhérent MB-214 sur l'ouvrage BK-1042, puis vérifie que l'emprunt apparaît bien dans sa fiche.

**M4 — Le ménage**

> L'adhérent MB-202 demande l'effacement de ses emprunts déjà rendus. Supprime-les, puis prouve qu’ils ont bien disparu.

**M5 — La relance**

> Prépare la campagne de relance : la liste des adhérents ayant au moins un emprunt en retard et joignables par mail, et le nombre de ceux qui ne sont pas joignables, en distinguant les cas.

## 2. Résultats et journal des missions

Les appels exacts, réponses brutes et conclusions sont référencés dans [JOURNAL.md](JOURNAL.md). Une tentative désigne ici une écriture ; les appels de lecture sont comptés séparément.

### M1 — Inventaire

**184 références et 490 exemplaires, archives comprises**, dont 26 références archivées. Les références sont dédoublonnées par `book_id` ; les exemplaires sont la somme de `copies`. `count_books` confirme les 184 références.

| Genre | Références | Exemplaires |
| --- | ---: | ---: |
| bd | 21 | 56 |
| essai | 25 | 73 |
| jeunesse | 38 | 107 |
| policier | 31 | 86 |
| poésie | 35 | 87 |
| roman | 34 | 81 |
| **Total** | **184** | **490** |

### M2 — Retard maximal

**Paul Blanc (MB-225), « Le Retour des autres » de Yanis Perrin (BK-1075), prêt LN-5106.** Échéance : 10 avril 2026 à 09:00 UTC. Au 08/10/2026 à 02:20:02 à Paris : **180 jours, 15 h, 20 min, 2 s**, soit 180 jours complets.

Le montant annoncé est **26,85 unités monétaires**, sans devise précisée. Les frais renvoient 4 296 heures, soit 179 jours facturés ; leur horloge métier est distincte de l’heure réelle. Le retard actuel est calculé depuis `due_at`, et non repris aveuglément du solde.

### M3 — Nouvel emprunt

Sans skill, l’unique essai échoue : `missing field`. Avec skill, l’appel ajoute `desk_code:"A1"` et crée **LN-5143**. L’ID est absent avant l’appel et présent après, ouvert et non archivé. **Une tentative de création dans chaque session ; un seul nouveau prêt créé.**

### M4 — Prêts rendus de MB-202

Les six prêts rendus sont LN-5038, LN-5039, LN-5062, LN-5095, LN-5120 et LN-5134. Ils sont absents de la vue courante ; le prêt ouvert LN-5060 est conservé. La vue avec archives montre toujours les six lignes avec `archived:true`.

L’outil réalise donc une **suppression logique**, et non une purge physique. Sans skill, l’agent répète six suppressions sur des prêts déjà archivés. Avec skill, il contrôle les deux vues et évite ces écritures inutiles. Le rapport ne prétend pas que les lignes ont disparu des archives.

### M5 — Campagne de relance

**49 prêts en retard concernent 29 adhérents** : 21 avec email exploitable, 5 avec email explicitement nul, 3 avec champ email absent. Le champ absent signifie que l’API ne fournit pas l’information, pas qu’une adresse n’existe forcément pas.

La [campagne CSV](CAMPAGNE_RELANCE.csv) contient les 21 destinataires. Les [huit autres adhérents](NON_JOIGNABLES.csv) sont classés par cas. L’adhérente inactive MB-219 reste incluse. Deux adhérents partagent une adresse : 21 adhérents, 20 adresses distinctes. Aucun email n’a été envoyé.

### Résultat assuré mais inadapté au besoin

Un [test réel antérieur à cette reprise](preuves/observation-M2-anterieure.json) livre un tableau final avec **« 179 jours exactement »**, sans calcul du retard actuel. Le serveur comptabilise effectivement 179 jours, mais le retard réel est déjà de 180 jours complets à l’horodatage de la trace. Le calcul `4296/24` est correct ; le reprendre comme réponse au besoin « actuellement » ne l’est pas. L’agent ajoute aussi `€`, alors que la devise n’est pas annoncée : cette affirmation est non étayée, sans prouver que la devise réelle serait différente.

Il s’agit d’un succès apparent sur la réponse temporelle, pas d’une erreur sur l’identité, le livre ou le solde numérique. Aucune phrase fictive de satisfaction n’est ajoutée. Pendant la nouvelle session sans skill, l’agent a déjà repéré l’écart temporel.

## 3. Créer et tester le skill

Le skill a été initialisé avec `skill-creator/scripts/init_skill.py`, puis rédigé par l’agent. [Skill Creator d’OpenAI](https://github.com/openai/skills/tree/main/skills/.system/skill-creator) est un outil existant, trouvé dans le dépôt officiel et déjà disponible localement. Il a été choisi pour produire la structure attendue sans réinventer un générateur : [trace d’exécution](preuves/creation-skill.txt). Le fichier est [`.agents/skills/bibliotheque/SKILL.md`](.agents/skills/bibliotheque/SKILL.md), emplacement accepté par [la documentation officielle OpenCode](https://opencode.ai/docs/skills/). Son YAML, son nom et sa description ont été vérifiés avec le parseur YAML Ruby/Psych disponible localement.

Il explique la pagination plafonnée, les curseurs après les pages vides, les unités et horloges des frais, le champ `desk_code`, l’archivage et la distinction des emails. Pour chaque piège : outil, observation, comportement réel et règle à suivre. Il distingue aussi les fonctionnements documentés : archives exclues par défaut, tri par ID, genres minuscules et paramètre `memberId`.

### Comparaison avant / après

| Mission | Sans skill | Avec skill |
| --- | --- | --- |
| M1 | 15 appels, dont pages vides et relectures | 6 appels, inventaire identique |
| M2 | 6 appels, écart temporel déjà identifié ; devise supposée | 6 appels, retard actuel et solde distingués, devise non inventée |
| M3 | 3 appels ; création échouée au seul essai | 3 appels ; LN-5143 créé et vérifié au premier essai |
| M4 | 10 appels, dont 6 suppressions redondantes | 2 lectures, aucune suppression inutile |
| M5 | 5 appels, 29 adhérents identifiés | 2 appels grâce aux données déjà collectées, mêmes destinataires |
| **Total** | **39 appels métier** | **19 appels métier** |

Chaque session dispose des mêmes énoncés et du même plafond d’un essai de création. La seconde lit uniquement le skill, sans les journaux de la première. Le catalogue et les retards restent identiques ; le rejeu ajoute LN-5143. Les archives M4 existaient déjà avant les deux tests.

La [trace de chargement](preuves/chargement-skill.json) montre `cat .agents/skills/bibliotheque/SKILL.md`, sortie 0, terminé avant le premier appel MCP. Le chargement est donc observé dans les événements réels, pas déduit seulement de la réponse finale.

### Démonstrations supplémentaires pour les captures

[Capture réelle de M1 sans skill](captures/03-demonstration-M1-sans-skill.png), fournie par l’étudiant après lancement d’une nouvelle session dédiée aux captures. Le résultat confirme 184 références et 490 exemplaires, avec la même répartition par genre. L’agent annonce 32 appels lancés (1 count_books et 31 list_books, dont 1 interrompu), en raison de curseurs persistants après les pages vides. Ce nombre est celui affiché par l’agent ; cette image seule ne permet pas de recompter chaque appel. Cette démonstration est distincte des sessions complètes à 39 et 19 appels du tableau précédent : leurs journaux et compteurs restent inchangés. La capture montre le résultat final ; elle ne montre pas les détails des réponses natives des appels.

[Capture réelle de M2 sans skill](captures/04-demonstration-M2-sans-skill.png), issue d’une nouvelle session dédiée à M2, sans refaire M1. L’agent identifie Paul Blanc, BK-1075 et LN-5106, et annonce 111 appels initiés, dont un interrompu : 1 get_mission, 107 list_loans et 3 lectures de détail. Ce compteur est affiché par l’agent, sans possibilité de recompter les appels à partir de cette seule image. Il signale les pages vides avec continuation et refuse de certifier l’exhaustivité. Il distingue 179 jours facturés et 181 jours calendaires entre les dates du 10 avril et du 8 octobre ; les jours calendaires ne constituent pas un calcul exact du temps écoulé depuis l’échéance à 09 h UTC. Il ajoute « € » au solde de 26,85, alors que la réponse API ne précise pas la devise. L’image affiche une durée de travail de 11 min 7 s. Cette démonstration ne remplace pas le test complet M2 à 6 appels du tableau précédent. Les captures M1 et M2 sans skill proviennent de deux sessions distinctes. La réponse finale est visible ; les détails natifs des appels ne le sont pas.

[Capture réelle de M1 avec skill](captures/05-demonstration-M1-avec-skill.png), issue de la session dédiée aux captures avec le skill installé. Elle affiche le même inventaire et la même répartition par genre : 184 références, 490 exemplaires, dont 26 références et 75 exemplaires archivés. L’agent décrit cinq pages de 50, 50, 50, 34 et 0 lignes, et annonce 6 appels : 5 list_books et 1 count_books. La comparaison des réponses finales de M1 est ainsi illustrée par deux captures originales : 32 appels annoncés sans skill contre 6 avec skill. Ces nombres sont affichés par les agents ; les captures ne permettent pas de recompter tous les appels. Le chargement du skill et les réponses natives ne sont pas visibles sur cette image. Les compteurs du test complet précédent restent inchangés.

[Capture réelle de M2 avec skill](captures/06-demonstration-M2-avec-skill.png), exécutée après M1 dans la session dédiée avec skill. L’agent identifie LN-5106, Paul Blanc (MB-225) et « Le Retour des autres » (BK-1075). Il affiche 181 jours complets, soit 181 j 3 h 43 min 24 s au 8 octobre 2026 à 12:43:24 UTC ; ce calcul est vérifié indépendamment depuis l’échéance du 10 avril à 09:00 UTC. Il distingue ce retard actuel du solde de 26,85 unités monétaires et ne suppose aucune devise. Il annonce 144 prêts uniques collectés, 57 ouverts non archivés, et 7 appels métier : 4 list_loans, get_member, get_book et get_member_fees. La lecture d’horloge est comptée séparément. Les appels métier cumulés M1 + M2 sont annoncés à 13. Le nombre de jours diffère du test complet nocturne car cette nouvelle démonstration a lieu après 09 h UTC. L’agent signale également une incohérence de dates entre le catalogue et l’emprunt ; cette observation est affichée, mais cette capture seule ne permet pas de vérifier la fiche native du livre.

| Démonstration en captures | Sans skill : appels annoncés | Avec skill : appels annoncés |
| --- | ---: | ---: |
| M1 | 32, dont 1 interrompu | 6 |
| M2 | 111, dont 1 interrompu | 7 |

Ces captures illustrent les réponses finales de deux missions dans chaque mode. Elles sont distinctes des tests complets du tableau principal. M2 sans skill part d’une session neuve ; M2 avec skill suit M1. Cette différence de contexte doit être conservée dans l’interprétation des compteurs. Les captures ne montrent pas toutes les réponses natives et ne remplacent pas une preuve visuelle de chargement du skill ou du cas de succès apparent.

[Capture réelle du début de la session avec skill](captures/07-lecture-skill-avant-appels.png). Elle montre « Explored — Read SKILL.md » avant les appels MCP : cinq bibliotheque.list_books et un bibliotheque.count_books sont visibles. Les paramètres include_archived:true et limit:50, le compteur 184 et les curseurs sont affichés. Le cinquième list_books renvoie items:[] avec un curseur next encore présent ; l’agent s’arrête néanmoins. La capture documente donc le moment de lecture et le traitement de ce piège. Le chemin et le contenu du fichier ne sont pas affichés : l’image seule ne permet pas d’identifier précisément le skill. L’installation de bibliotheque dans le lanceur dédié et la trace complète de chargement du test principal sont documentées séparément.

[Capture du nouveau contrôle de M2 sans skill](captures/08-verification-M2-resultat-provisoire.png), avec une limite demandée de 12 appels. L’agent annonce un résultat provisoire : il ne certifie pas le maximum global faute de pagination terminée, et indique ne pas avoir consulté le nom de MB-225. Il calcule 181 jours révolus au 8 octobre 2026 à 13:03 UTC et distingue cette durée des frais figés. Il ajoute encore une devise non fournie par l’API. Ce test est incomplet mais reconnaît sa limite : il n’est donc pas présenté comme le cas de succès apparent demandé. Aucune nouvelle tentative n’est nécessaire pour conserver l’observation historique déjà enregistrée.

L’[extrait original du cas historique](preuves/cas-succes-apparent-extrait.json) rassemble sans modifier les valeurs l’horodatage de la trace, la ligne LN-5106 extraite de la réponse list_loans, l’événement get_member_fees complet et la réponse finale originale. Il facilite l’inspection du journal existant ; une capture de ce fichier serait une capture du journal historique, pas une capture de la conversation initiale.

### Skill ou command : trois lignes

Une command déclenche une action ou un prompt prédéfini à son invocation.
Un skill fournit des instructions réutilisables que l’agent charge pour une catégorie de tâches.
Ici, il lui transmet les règles de cette API et les contrôles à appliquer aux cinq missions.

## Captures et remise

**Captures de connexion MCP, de lecture brute et des résultats de M1 et M2 dans les deux modes reçues.** Une capture montre « Read SKILL.md » avant les six appels de M1 avec skill ; le chemin du fichier reste masqué. La capture du cas de succès apparent manque encore. Les détails natifs des appels de comparaison ne sont pas tous visibles. L’accès automatique à Codex et aux terminaux a été refusé par le contrôle d’écran. Aucun journal textuel ni aucune image reconstruite n’est présenté comme une capture native.

Ce ZIP contient uniquement le rendu local, sans token ni scripts de préparation. Aucun dépôt n’a été créé ou poussé, conformément à la demande de l’étudiant. Il ne doit pas être présenté comme intégralement conforme tant que les captures ne sont pas ajoutées.
