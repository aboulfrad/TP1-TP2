---
name: bibliotheque
description: Réaliser les missions du MCP bibliotheque du TP en tenant compte de sa pagination, de ses unités et de ses opérations de création et d'archivage.
---

# Bibliothèque — API du TP

Utiliser ces règles pour le serveur `ai-tools-mcp-biblio-production.up.railway.app/mcp`. Lire les descriptions des outils et vérifier les résultats avec les données brutes.

## Pièges et règles

| Outil | Observation et comportement réel | Règle à appliquer |
| --- | --- | --- |
| `list_books`, `list_members`, `list_loans` | La taille effective des pages est plafonnée à 50. Une page vide peut encore contenir `next`. | Demander 50, transmettre le curseur sans le modifier. Pour un scan **non filtré**, arrêter à la première page vide et dédoublonner les IDs. Une page courte seule ne suffit pas. |
| `get_member_fees` | `overdue_duration=4296`, `late_fee_per_day=15`, `balance_due=26.85` correspondent à 179 jours facturés à 0,15 unité par jour. Les frais reposent sur une horloge métier figée. | La durée est en heures et le tarif en centièmes. Utiliser le solde tel quel ; ne pas inventer la devise. Pour le retard **actuel**, calculer depuis `due_at` avec une heure réelle datée, indépendamment des frais. |
| `create_loan` | Les deux paramètres documentés donnent `missing field`. Le serveur exige aussi `desk_code`, absent du schéma. | Ajouter un code observé dans les prêts, tel que `A1`. Relever les IDs avant l'appel et vérifier le **nouvel ID** ensuite, sans confondre avec un prêt existant. |
| `delete_loan` | `deleted:true` masque le prêt du registre courant ; la ligne reste présente avec `archived:true` lorsque les archives sont incluses. | Sélectionner seulement les prêts rendus de l'adhérent. Préserver les ouverts. Vérifier les deux vues et annoncer une suppression logique, sans promettre une purge physique. Ne pas réarchiver inutilement une ligne déjà archivée. |
| `list_members`, `get_member` | Un email peut être explicitement `null` ou absent du JSON. Plusieurs adhérents peuvent partager une adresse ou un nom. | Distinguer email exploitable, email nul et champ absent. Dédoublonner par `member_id`, pas par adresse. Inclure les adhérents inactifs s'ils ont un retard. Préparer la campagne sans envoyer de mail. |

## Réaliser les missions

1. **Inventaire** : collecter le catalogue avec `include_archived:true`. Compter les références uniques et les exemplaires (`copies`), puis les répartir par genre. Recouper les références avec `count_books`.
2. **Retard maximal** : collecter les prêts sans filtre, archives comprises, puis conserver les prêts ouverts non archivés. Chercher le plus petit `due_at`. Les timestamps sont en secondes Unix ; les jours complets valent `floor((maintenant - due_at)/86400)`. Retrouver l'adhérent, le livre et son solde.
3. **Création** : noter les IDs du couple adhérent/livre, créer une fois avec `desk_code`, puis relire la fiche des prêts pour prouver l'apparition du nouvel ID.
4. **Ménage** : relire les prêts de l'adhérent avec et sans archives. Archiver les rendus qui ne le sont pas déjà, puis vérifier qu'ils sont absents de la vue courante et que les ouverts sont conservés.
5. **Relances** : joindre les prêts ouverts non archivés dont `due_at` est passé aux adhérents. Une ligne par adhérent. Produire la liste avec email et compter séparément les emails nuls et les champs absents.

## Fonctionnements normaux

Les archives sont exclues par défaut du catalogue ; ce comportement est documenté. Les prêts sont triés par `loan_id`, et non par retard. Les genres sont les valeurs minuscules annoncées. `get_member` utilise le paramètre documenté `memberId`. Ces différences ne constituent pas des bugs.
