# Journal des cinq missions

Les fichiers [sans skill](preuves/appels-sans-skill.json) et [avec skill](preuves/appels-avec-skill.json) conservent **chaque appel exact et sa réponse native complète**, dans l’ordre. Les champs `arguments`, `result` et `error` permettent de distinguer l’appel, la réponse brute et un éventuel échec. Les conclusions originales sont conservées [sans skill](preuves/sans-skill-reponse.txt) et [avec skill](preuves/avec-skill-reponse.txt).

| Mission | Appels sans / avec | Conclusion retenue et observation |
| --- | --- | --- |
| M1 | 15 / 6 | 184 références, 490 exemplaires ; des pages vides continuent à retourner un curseur. |
| M2 | 6 / 6 | LN-5106, 180 jours complets ; distinguer retard réel et facturation. La devise ajoutée sans skill n'est pas justifiée. |
| M3 | 3 / 3 | `missing field` sans `desk_code` ; avec ce champ, nouvel ID LN-5143 relu. Une tentative d'écriture par session. |
| M4 | 10 / 2 | Six suppressions sans effet nouveau, puisque les rendus sont déjà archivés ; les deux vues montrent la suppression logique. LN-5060 préservé. |
| M5 | 5 / 2 | 21 emails exploitables, 5 nuls, 3 absents ; identité dédoublonnée sur l'ID. |

## Création : appel et réponse déterminants

Sans skill :

```json
{
  "arguments": {
    "member_id": "MB-214",
    "book_id": "BK-1042"
  },
  "response": {
    "ok": false,
    "error": "missing field"
  }
}
```

Avec skill :

```json
{
  "arguments": {
    "member_id": "MB-214",
    "book_id": "BK-1042",
    "desk_code": "A1"
  },
  "response": {
    "ok": true,
    "loan": {
      "loan_id": "LN-5143",
      "book_id": "BK-1042",
      "member_id": "MB-214",
      "started_at": 1791277200,
      "due_at": 1793091600,
      "returned_at": null,
      "status": "open",
      "archived": false,
      "desk_code": "A1"
    }
  }
}
```

L'appel `list_loans` suivant retrouve LN-5143. Celui précédant la création ne le contient pas. Ces deux réponses sont conservées intégralement dans le fichier avec skill.

## Suppression : réponse et contrôle

```json
{
  "arguments": {
    "loan_id": "LN-5038"
  },
  "response": {
    "ok": true,
    "deleted": true,
    "loan_id": "LN-5038"
  }
}
```

La vue courante de MB-202 contient seulement LN-5060 ; la vue avec archives contient les six rendus. L’agent sans skill a constaté cette persistance : elle ne constitue donc pas, dans ce test, un faux succès déclaré par l’agent. Le cas temporel M2 antérieur est expliqué séparément dans le rapport.
